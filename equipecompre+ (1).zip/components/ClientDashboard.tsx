import React, { useState, useEffect } from 'react';
import { User, REWARDS, SubscriptionTier, TIERS, Transaction, PendingReferral } from '../types';
import { Logo } from './Logo';
import { 
  Gift, 
  Zap, 
  Crown, 
  CheckCircle, 
  Smartphone, 
  Headphones, 
  Cable, 
  Percent, 
  Home,
  Clock,
  LogOut,
  Menu,
  Check,
  ShoppingBag,
  Send,
  User as UserIcon,
  Save,
  Loader2,
  Search,
  AlertTriangle,
  X,
  Eye,
  EyeOff,
  Sparkles,
  Heart,
  Star,
  ArrowLeft,
  Share2,
  Download,
  Smartphone as PhoneIcon,
  Users
} from 'lucide-react';
import { checkUsernameExists, getCurrentUser } from '../services/authService';

interface Props {
  user: User;
  onLogout: () => void;
  onUserUpdate: (user: User) => void;
  isImpersonating?: boolean;
  onStopImpersonating?: () => void;
}

type ViewState = 'HOME' | 'HISTORY' | 'PLANS' | 'PROFILE';

const BR_STATES = [
  'AC', 'AL', 'AP', 'AM', 'BA', 'CE', 'DF', 'ES', 'GO', 'MA', 'MT', 'MS',
  'MG', 'PA', 'PB', 'PR', 'PE', 'PI', 'RJ', 'RN', 'RS', 'RO', 'RR', 'SC',
  'SP', 'SE', 'TO'
];

const ClientDashboard: React.FC<Props> = ({ user, onLogout, onUserUpdate, isImpersonating, onStopImpersonating }) => {
  const [currentView, setCurrentView] = useState<ViewState>('HOME');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [showTutorial, setShowTutorial] = useState(false);
  const [showInstallGuide, setShowInstallGuide] = useState(false);
  const [showReferralModal, setShowReferralModal] = useState(false);

  // Real-time sync: Check for updates (e.g. Admin approved points) every few seconds
  useEffect(() => {
    const intervalId = setInterval(() => {
      const freshUser = getCurrentUser();
      if (freshUser && freshUser.id === user.id) {
        // If points or status changed externally (by Admin), update local state
        if (Number(freshUser.points) !== Number(user.points) || 
            freshUser.pendingPurchase !== user.pendingPurchase ||
            freshUser.tier !== user.tier || 
            freshUser.pendingTier !== user.pendingTier ||
            (freshUser.pendingReferrals?.length !== user.pendingReferrals?.length)) {
          onUserUpdate(freshUser);
        }
      }
    }, 2000); // Check every 2 seconds

    return () => clearInterval(intervalId);
  }, [user, onUserUpdate]);

  useEffect(() => {
    // Show tutorial on first access ONLY if not impersonating
    if (!isImpersonating) {
      const hasSeenTutorial = localStorage.getItem(`tutorial_seen_${user.id}`);
      if (!hasSeenTutorial) {
        setShowTutorial(true);
        localStorage.setItem(`tutorial_seen_${user.id}`, 'true');
      }
    }
  }, [user.id, isImpersonating]);

  // Ensure points are treated as numbers
  const safePoints = Number(user.points) || 0;
  
  // Calculate Next Milestone
  const getNextMilestone = () => {
    if (safePoints < 100) return 100;
    if (safePoints < 200) return 200;
    if (safePoints < 300) return 300;
    if (safePoints < 400) return 400;
    return 500;
  };

  const nextMilestone = getNextMilestone();
  const progress = Math.min((safePoints / 500) * 100, 100);
  
  const currentTierData = TIERS[user.tier];
  
  // Format history safely
  const history = user.history || [];

  // Dynamic Greeting
  const getTimeBasedGreeting = () => {
    const hour = new Date().getHours();
    if (hour < 12) return 'Bom dia';
    if (hour < 18) return 'Boa tarde';
    return 'Boa noite';
  };

  // Motivational Message based on points
  const getMotivationalMessage = () => {
    if (safePoints >= 500) return "Incrível! Você atingiu a meta máxima! Resgate seu prêmio agora.";
    return `Vamos lá, sua meta atual é chegar nos ${nextMilestone}pts!`;
  };

  const getRewardIcon = (iconName: string, size = 20) => {
    switch (iconName) {
      case 'smartphone': return <Smartphone size={size} />;
      case 'cable': return <Cable size={size} />;
      case 'zap': return <Zap size={size} />;
      case 'headphones': return <Headphones size={size} />;
      case 'percent': return <Percent size={size} />;
      default: return <Gift size={size} />;
    }
  };

  const handleClaimReward500 = () => {
    if (safePoints < 500) return;
    const confirm = window.confirm("Parabéns! Deseja resgatar seu desconto de R$50 e reiniciar seus pontos?");
    if (confirm) {
      const redemption: Transaction = {
        id: Date.now().toString(),
        date: new Date().toISOString(),
        points: -500,
        type: 'REDEEM',
        description: 'Resgate de Desconto R$50'
      };

      const updatedUser = { 
        ...user, 
        points: safePoints - 500,
        history: [redemption, ...history]
      };
      
      // Update globally
      onUserUpdate(updatedUser);
      alert("Resgate realizado! Apresente esta tela ao caixa.");
    }
  };

  const handleRegisterPurchase = () => {
    // 1. Mark as pending in the system
    const updatedUser: User = { ...user, pendingPurchase: true };
    onUserUpdate(updatedUser);

    // 2. Send WhatsApp notification
    const message = `
*SOLICITAÇÃO DE PONTOS - EquipeCompre+* 🛍️
    
Olá! Acabei de realizar uma compra na loja.
    
👤 *Cliente:* ${user.fullName}
🆔 *CPF:* ${user.cpf}
    
Por favor, confirme minha compra para eu ganhar meus 10 pontos!
    `.trim();

    const phone = "5521985415117"; 
    const url = `https://wa.me/${phone}?text=${encodeURIComponent(message)}`;
    window.open(url, '_blank');
  };

  const handleSubscribe = (tierKey: string) => {
    const tier = tierKey as SubscriptionTier;
    const tierData = TIERS[tier];

    // 1. Update User State to Pending
    const updatedUser: User = {
      ...user,
      pendingTier: tier
    };
    onUserUpdate(updatedUser);

    // 2. Send WhatsApp Notification
    const message = `
*NOVA ASSINATURA VIP - EquipeCompre+* 👑

Olá! Gostaria de assinar o plano VIP.

👤 *Colaborador/Cliente:* ${user.fullName}
🆔 *CPF:* ${user.cpf}
📦 *Plano Escolhido:* ${tierData.name} (R$${tierData.price.toFixed(2)})

Aguardo a aprovação no painel!
    `.trim();

    const phone = "5521985415117"; 
    const url = `https://wa.me/${phone}?text=${encodeURIComponent(message)}`;
    window.open(url, '_blank');
  };

  // Referral Modal Component
  const ReferralModal = () => {
    const [name, setName] = useState('');
    const [phone, setPhone] = useState('');

    const handleSubmit = (e: React.FormEvent) => {
      e.preventDefault();
      
      const newReferral: PendingReferral = {
        id: Date.now().toString(),
        name: name,
        phone: phone,
        date: new Date().toISOString()
      };

      // Update User State
      const currentReferrals = user.pendingReferrals || [];
      const updatedUser: User = {
        ...user,
        pendingReferrals: [...currentReferrals, newReferral]
      };
      onUserUpdate(updatedUser);

      // WhatsApp Notification to Admin
      const message = `
*NOVA INDICAÇÃO - EquipeCompre+* 🗣️

Olá! Estou indicando um amigo para ganhar pontos.

👤 *Eu:* ${user.fullName}
👉 *Indiquei:* ${name}
📞 *Tel do Amigo:* ${phone}

Aguardando aprovação dos meus +10 pontos!
      `.trim();
      
      const adminPhone = "5521985415117"; 
      const url = `https://wa.me/${adminPhone}?text=${encodeURIComponent(message)}`;
      window.open(url, '_blank');

      setShowReferralModal(false);
    };

    if (!showReferralModal) return null;

    return (
      <div className="fixed inset-0 z-[80] flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm animate-fade-in">
        <div className="bg-white w-full max-w-sm rounded-2xl shadow-2xl p-6 relative">
          <button 
             onClick={() => setShowReferralModal(false)} 
             className="absolute top-4 right-4 bg-gray-100 hover:bg-gray-200 text-gray-600 p-2 rounded-full transition"
           >
             <X size={20}/>
           </button>
           
           <div className="text-center mb-6">
             <div className="w-16 h-16 bg-purple-100 text-purple-600 rounded-full flex items-center justify-center mx-auto mb-3">
               <Users size={32} />
             </div>
             <h3 className="text-xl font-bold text-gray-800">Indicar Amigo</h3>
             <p className="text-sm text-gray-500">Preencha os dados de quem você está indicando.</p>
           </div>

           <form onSubmit={handleSubmit} className="space-y-4">
             <div>
               <label className="text-xs font-bold text-gray-500 uppercase ml-1">Nome do Amigo</label>
               <input required value={name} onChange={e => setName(e.target.value)} className="w-full p-3 border rounded-xl bg-gray-50 focus:ring-2 focus:ring-purple-500 outline-none" placeholder="Ex: Maria Souza" />
             </div>
             <div>
               <label className="text-xs font-bold text-gray-500 uppercase ml-1">Telefone / WhatsApp</label>
               <input required value={phone} onChange={e => setPhone(e.target.value)} className="w-full p-3 border rounded-xl bg-gray-50 focus:ring-2 focus:ring-purple-500 outline-none" placeholder="(21) 99999-9999" />
             </div>
             
             <button type="submit" className="w-full py-3 bg-purple-600 text-white font-bold rounded-xl hover:bg-purple-700 shadow-lg shadow-purple-200 transition active:scale-95">
               ENVIAR INDICAÇÃO
             </button>
           </form>
        </div>
      </div>
    );
  };

  const InstallGuideModal = () => {
    if (!showInstallGuide) return null;

    return (
      <div className="fixed inset-0 z-[70] flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in">
        <div className="bg-white w-full max-w-md rounded-2xl shadow-2xl p-6 relative">
          <button 
             onClick={() => setShowInstallGuide(false)} 
             className="absolute top-4 right-4 bg-gray-100 hover:bg-gray-200 text-gray-600 p-2 rounded-full transition"
           >
             <X size={20}/>
           </button>
           
           <div className="text-center mb-6">
             <div className="w-16 h-16 bg-blue-100 text-blue-600 rounded-2xl flex items-center justify-center mx-auto mb-4">
               <Download size={32} />
             </div>
             <h3 className="text-2xl font-bold text-gray-800">Instalar Aplicativo</h3>
             <p className="text-gray-500 mt-2">Tenha o EquipeCompre+ direto na tela inicial do seu celular.</p>
           </div>

           <div className="space-y-6">
             <div className="bg-gray-50 p-4 rounded-xl border border-gray-100">
               <h4 className="font-bold text-gray-800 flex items-center gap-2 mb-2">
                 <Smartphone size={18} className="text-green-600" /> Android (Chrome)
               </h4>
               <ol className="text-sm text-gray-600 space-y-2 list-decimal list-inside">
                 <li>Toque no menu de <strong>três pontos</strong> (⋮) no topo.</li>
                 <li>Selecione <strong>"Adicionar à tela inicial"</strong>.</li>
                 <li>Confirme clicando em <strong>Adicionar</strong>.</li>
               </ol>
             </div>

             <div className="bg-gray-50 p-4 rounded-xl border border-gray-100">
               <h4 className="font-bold text-gray-800 flex items-center gap-2 mb-2">
                 <PhoneIcon size={18} className="text-gray-800" /> iPhone (Safari)
               </h4>
               <ol className="text-sm text-gray-600 space-y-2 list-decimal list-inside">
                 <li>Toque no botão <strong>Compartilhar</strong> (quadrado com seta).</li>
                 <li>Role para baixo e toque em <strong>"Adicionar à Tela de Início"</strong>.</li>
                 <li>Confirme clicando em <strong>Adicionar</strong>.</li>
               </ol>
             </div>
           </div>
           
           <button 
             onClick={() => setShowInstallGuide(false)}
             className="w-full mt-6 py-3 bg-blue-600 text-white font-bold rounded-xl hover:bg-blue-700 transition"
           >
             Entendi
           </button>
        </div>
      </div>
    );
  };

  const TutorialModal = () => {
    if (!showTutorial) return null;

    return (
      <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in">
        <div className="bg-white w-full max-w-2xl rounded-3xl shadow-2xl overflow-hidden flex flex-col relative">
          
          {/* Header with decorative background */}
          <div className="bg-gradient-to-r from-blue-600 to-indigo-700 p-8 text-center relative overflow-hidden">
             <div className="absolute top-0 left-0 w-full h-full opacity-10">
               <Sparkles className="absolute top-4 left-4 text-white" size={40} />
               <Star className="absolute bottom-4 right-4 text-white" size={60} />
               <Heart className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 text-white" size={100} />
             </div>
             
             <div className="relative z-10">
               <div className="w-20 h-20 bg-white rounded-full flex items-center justify-center mx-auto mb-4 shadow-lg text-blue-600">
                 <Logo size="sm" />
               </div>
               <h2 className="text-3xl font-bold text-white mb-2">Bem-vindo(a) à Família!</h2>
               <p className="text-blue-100 text-lg">Estamos muito felizes em ter você aqui.</p>
             </div>
             
             <button 
               onClick={() => setShowTutorial(false)} 
               className="absolute top-4 right-4 bg-white/20 hover:bg-white/30 text-white p-2 rounded-full transition"
             >
               <X size={20}/>
             </button>
          </div>

          {/* Motivational Content */}
          <div className="p-8 text-center space-y-6">
             <div className="prose prose-lg mx-auto text-gray-600 leading-relaxed">
               <p className="font-medium text-xl text-gray-800">
                 Olá, <span className="text-blue-600 font-bold">{user.fullName.split(' ')[0]}</span>! ✨
               </p>
               <p>
                 Sua jornada para <strong>economizar e ganhar prêmios</strong> incríveis começa agora. 
                 Cada compra que você fizer é um passo importante em direção a recompensas exclusivas que preparamos com muito carinho para você.
               </p>
               <p>
                 Nosso objetivo é ver você feliz e realizado. Conte conosco para fazer suas experiências de compra valerem muito mais!
               </p>
             </div>

             <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-left mt-6">
                <div className="bg-green-50 p-4 rounded-xl border border-green-100">
                  <div className="flex items-center gap-2 mb-2 text-green-700 font-bold">
                    <CheckCircle size={18} />
                    <span>Marque</span>
                  </div>
                  <p className="text-sm text-gray-600">Avise a cada compra para garantir seus pontos.</p>
                </div>
                <div className="bg-purple-50 p-4 rounded-xl border border-purple-100">
                  <div className="flex items-center gap-2 mb-2 text-purple-700 font-bold">
                    <Zap size={18} />
                    <span>Acumule</span>
                  </div>
                  <p className="text-sm text-gray-600">Veja seus pontos crescerem na barra de progresso.</p>
                </div>
                <div className="bg-yellow-50 p-4 rounded-xl border border-yellow-100">
                  <div className="flex items-center gap-2 mb-2 text-yellow-700 font-bold">
                    <Gift size={18} />
                    <span>Ganhe</span>
                  </div>
                  <p className="text-sm text-gray-600">Troque seus pontos por prêmios e descontos reais.</p>
                </div>
             </div>
          </div>
          
          <div className="p-6 border-t bg-gray-50 flex justify-center">
            <button 
              onClick={() => setShowTutorial(false)}
              className="bg-blue-600 text-white font-bold px-8 py-3 rounded-xl hover:bg-blue-700 transition shadow-lg shadow-blue-200 transform hover:-translate-y-1 active:translate-y-0"
            >
              Vamos Começar! 🚀
            </button>
          </div>
        </div>
      </div>
    );
  };

  // Components for Content
  
  const ProfileView = () => {
    const [formData, setFormData] = useState({
      username: user.username,
      password: user.password || '',
      fullName: user.fullName,
      email: user.email,
      phone: user.phone,
      street: user.address.street,
      number: user.address.number,
      complement: user.address.complement || '',
      district: user.address.district,
      city: user.address.city,
      uf: user.address.uf,
      cep: user.address.cep
    });
    const [loading, setLoading] = useState(false);
    const [loadingCep, setLoadingCep] = useState(false);
    const [showPassword, setShowPassword] = useState(false);

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
      setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    const handleCepChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
      const rawCep = e.target.value;
      setFormData(prev => ({ ...prev, cep: rawCep }));
      const cleanCep = rawCep.replace(/\D/g, '');

      if (cleanCep.length === 8) {
        setLoadingCep(true);
        try {
          const response = await fetch(`https://viacep.com.br/ws/${cleanCep}/json/`);
          const data = await response.json();
          if (!data.erro) {
            setFormData(prev => ({
              ...prev,
              street: data.logradouro,
              district: data.bairro,
              city: data.localidade,
              uf: data.uf,
            }));
          }
        } catch (error) {
          console.error("Erro CEP", error);
        } finally {
          setLoadingCep(false);
        }
      }
    };

    const handleSave = async (e: React.FormEvent) => {
      e.preventDefault();
      setLoading(true);

      if (checkUsernameExists(formData.username, user.id)) {
        alert("Nome de usuário já existe. Escolha outro.");
        setLoading(false);
        return;
      }

      await new Promise(r => setTimeout(r, 800)); // Simulate network

      const updatedUser: User = {
        ...user,
        username: formData.username,
        fullName: formData.fullName,
        email: formData.email,
        phone: formData.phone,
        password: formData.password,
        address: {
          street: formData.street,
          number: formData.number,
          complement: formData.complement,
          district: formData.district,
          city: formData.city,
          uf: formData.uf,
          cep: formData.cep
        }
      };

      onUserUpdate(updatedUser);
      setLoading(false);
      alert("Dados atualizados com sucesso!");
    };

    return (
      <div className="max-w-4xl animate-fade-in">
        <h2 className="text-2xl font-bold text-gray-800 mb-6 flex items-center gap-2">
          <UserIcon className="text-blue-600" /> Meus Dados
        </h2>
        
        <form onSubmit={handleSave} className="bg-white p-6 md:p-8 rounded-2xl shadow-sm border border-gray-100 grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="col-span-1 md:col-span-2 bg-blue-50 p-4 rounded-xl mb-2">
             <h3 className="font-bold text-blue-800 mb-3">Informações de Acesso</h3>
             <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-bold text-blue-600 uppercase ml-1">Usuário</label>
                  <input required name="username" value={formData.username} onChange={handleChange} className="w-full p-2 bg-white border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 outline-none" />
                </div>
                <div className="relative">
                  <label className="text-xs font-bold text-blue-600 uppercase ml-1">Senha</label>
                  <input required type={showPassword ? "text" : "password"} name="password" value={formData.password} onChange={handleChange} className="w-full p-2 bg-white border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 outline-none pr-10" />
                  <button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute right-2 top-8 text-gray-400 hover:text-blue-600">
                     {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                  </button>
                </div>
             </div>
          </div>

          <div>
             <label className="text-xs font-bold text-gray-500 uppercase ml-1">Nome Completo</label>
             <input required name="fullName" value={formData.fullName} onChange={handleChange} className="w-full p-2 bg-white border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 outline-none" />
          </div>

          <div>
             <label className="text-xs font-bold text-gray-500 uppercase ml-1">CPF (Não alterável)</label>
             <input disabled value={user.cpf} className="w-full p-2 bg-gray-200 border border-gray-300 rounded text-gray-500 cursor-not-allowed" />
          </div>

          <div>
             <label className="text-xs font-bold text-gray-500 uppercase ml-1">Email</label>
             <input required name="email" value={formData.email} onChange={handleChange} className="w-full p-2 bg-white border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 outline-none" />
          </div>

          <div>
             <label className="text-xs font-bold text-gray-500 uppercase ml-1">Telefone / WhatsApp</label>
             <input required name="phone" value={formData.phone} onChange={handleChange} className="w-full p-2 bg-white border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 outline-none" />
          </div>

          <div className="col-span-1 md:col-span-2 border-t pt-4 mt-2">
            <h3 className="font-bold text-gray-700 mb-4 flex items-center gap-2">
              <span className="bg-gray-100 p-1.5 rounded text-gray-600"><Home size={16}/></span> Endereço
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-6 gap-4">
               <div className="md:col-span-2 relative">
                 <label className="text-xs font-bold text-gray-500 uppercase ml-1">CEP</label>
                 <div className="relative">
                   <input required name="cep" value={formData.cep} onChange={handleCepChange} maxLength={9} className="w-full p-2 bg-white border border-gray-300 rounded pr-8 focus:ring-2 focus:ring-blue-500 outline-none" />
                   <div className="absolute right-2 top-1/2 -translate-y-1/2 text-gray-400">
                     {loadingCep ? <Loader2 className="animate-spin text-blue-500" size={14} /> : <Search size={14} />}
                   </div>
                 </div>
               </div>
               <div className="md:col-span-3">
                 <label className="text-xs font-bold text-gray-500 uppercase ml-1">Rua</label>
                 <input required name="street" value={formData.street} onChange={handleChange} className="w-full p-2 bg-white border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 outline-none" />
               </div>
               <div className="md:col-span-1">
                 <label className="text-xs font-bold text-gray-500 uppercase ml-1">Número</label>
                 <input required name="number" value={formData.number} onChange={handleChange} className="w-full p-2 bg-white border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 outline-none" />
               </div>
               <div className="md:col-span-2">
                 <label className="text-xs font-bold text-gray-500 uppercase ml-1">Complemento</label>
                 <input name="complement" value={formData.complement} onChange={handleChange} className="w-full p-2 bg-white border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 outline-none" />
               </div>
               <div className="md:col-span-2">
                 <label className="text-xs font-bold text-gray-500 uppercase ml-1">Bairro</label>
                 <input required name="district" value={formData.district} onChange={handleChange} className="w-full p-2 bg-white border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 outline-none" />
               </div>
               <div className="md:col-span-1">
                 <label className="text-xs font-bold text-gray-500 uppercase ml-1">Cidade</label>
                 <input required name="city" value={formData.city} onChange={handleChange} className="w-full p-2 bg-white border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 outline-none" />
               </div>
               <div className="md:col-span-2">
                 <label className="text-xs font-bold text-gray-500 uppercase ml-1">UF</label>
                 <select required name="uf" value={formData.uf} onChange={handleChange} className="w-full p-2 bg-white border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 outline-none">
                    {BR_STATES.map(s => <option key={s} value={s}>{s}</option>)}
                 </select>
               </div>
            </div>
          </div>

          <div className="col-span-1 md:col-span-2 pt-4 flex justify-end">
             <button disabled={loading} className="bg-green-600 text-white px-8 py-3 rounded-xl font-bold hover:bg-green-700 shadow-lg shadow-green-200 transition flex items-center gap-2">
               {loading ? <Loader2 className="animate-spin" /> : <><Save size={20} /> SALVAR ALTERAÇÕES</>}
             </button>
          </div>
        </form>
      </div>
    );
  };

  const HomeView = () => (
    <div className="space-y-8 animate-fade-in pb-20 md:pb-0">
      
      {/* Greeting Banner */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-2">
         <div>
            <h1 className="text-3xl md:text-4xl font-bold text-gray-800 tracking-tight">
              {getTimeBasedGreeting()}, <span className="text-blue-600">{user.fullName.split(' ')[0]}</span>!
            </h1>
            <p className="text-gray-500 text-lg mt-1">
               Que bom ter você aqui na EquipeCompre+.
            </p>
         </div>
      </div>

      {/* Stats Card */}
      <div className="bg-gradient-to-r from-blue-600 to-indigo-700 rounded-2xl shadow-xl p-8 text-white relative overflow-hidden ring-4 ring-blue-50 border-4 border-white/10">
         <div className="absolute top-0 right-0 p-4 opacity-10">
           <Gift size={200} />
         </div>
         
         <div className="relative z-10">
           <div className="flex items-start justify-between">
             <div>
               <div className={`inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wide bg-white/20 backdrop-blur-sm mb-4 border border-white/20 shadow-sm`}>
                 <Crown size={14} className="text-yellow-300" /> {currentTierData.name}
               </div>
               {user.pendingTier && (
                 <div className="block mt-1 text-xs bg-yellow-400 text-yellow-900 px-2 py-1 rounded items-center gap-1 font-bold animate-pulse inline-flex">
                   <AlertTriangle size={10} /> Solicitação: {TIERS[user.pendingTier].name}
                 </div>
               )}
               <p className="text-blue-200 font-medium tracking-wide">SEU SALDO ATUAL</p>
             </div>
             <div className="text-right">
               <p className="text-6xl font-extrabold tracking-tight drop-shadow-md">{safePoints}</p>
               <p className="text-blue-200 text-xs font-bold uppercase tracking-widest mt-1">PONTOS</p>
             </div>
           </div>

           <div className="mt-8">
             <div className="flex justify-between text-sm mb-3 font-medium text-blue-100 items-end">
               <span className="flex items-center gap-2">
                 <Sparkles size={16} className="text-yellow-300" />
                 <span className="italic text-yellow-100">"{getMotivationalMessage()}"</span>
               </span>
               <span className="text-2xl font-bold text-white">{Math.floor(progress)}%</span>
             </div>
             
             {/* Progress Bar Container */}
             <div className="w-full bg-black/30 rounded-full h-4 backdrop-blur-sm p-0.5 border border-white/10 shadow-inner">
               <div 
                 className="bg-gradient-to-r from-yellow-300 via-yellow-400 to-orange-500 h-full rounded-full shadow-[0_0_10px_rgba(253,224,71,0.5)] transition-all duration-1000 ease-out relative" 
                 style={{ width: `${Math.max(progress, 2)}%` }} // Ensure at least a tiny sliver is visible so it "leaves 0"
               >
                  <div className="absolute right-0 top-1/2 -translate-y-1/2 w-1 h-full bg-white/50 rounded-full"></div>
               </div>
             </div>
             <div className="flex justify-between mt-2 text-xs text-blue-300 font-mono">
               <span>{safePoints} pts</span>
               <span className="font-bold text-yellow-300">Meta: {nextMilestone} pts</span>
             </div>
           </div>
         </div>
      </div>

      {/* ACTION HERO: Register Purchase */}
      <div className="bg-white rounded-3xl shadow-xl overflow-hidden border-2 border-green-500 transform transition hover:scale-[1.01]">
        <div className="bg-green-500 p-2 text-center text-white font-bold text-sm tracking-widest uppercase">
          Área de Pontuação
        </div>
        <div className="p-6 md:p-8 flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="flex items-center gap-4">
            <div className="p-4 bg-green-100 rounded-full text-green-600 shadow-sm">
               <ShoppingBag size={40} strokeWidth={1.5} />
            </div>
            <div>
              <h2 className="text-2xl font-bold text-gray-800">Realizou uma compra?</h2>
              {user.pendingPurchase ? (
                 <p className="text-orange-600 font-bold animate-pulse">
                   Solicitação em análise pelo administrador...
                 </p>
              ) : (
                 <p className="text-gray-600">Avise a gente agora para liberar seus pontos!</p>
              )}
            </div>
          </div>
          <button 
            onClick={handleRegisterPurchase}
            disabled={!!user.pendingPurchase}
            className={`w-full md:w-auto px-8 py-4 rounded-xl font-bold text-lg shadow-lg flex items-center justify-center gap-3 transition-all ${
              user.pendingPurchase 
                ? 'bg-gray-300 text-gray-500 cursor-not-allowed' 
                : 'bg-green-600 hover:bg-green-700 text-white shadow-green-200 active:scale-95 animate-pulse-slow ring-2 ring-green-100'
            }`}
          >
            {user.pendingPurchase ? (
              <><Clock size={24} /> AGUARDANDO</>
            ) : (
              <><Send size={24} /> MARCAR COMPRA</>
            )}
          </button>
        </div>
      </div>

      {/* Referral Card - UPDATED FEATURE */}
      <div className="bg-gradient-to-r from-purple-600 to-indigo-600 rounded-3xl shadow-xl overflow-hidden text-white relative">
        <div className="absolute right-0 bottom-0 opacity-20 transform translate-x-10 translate-y-10">
          <Share2 size={180} />
        </div>
        <div className="p-6 md:p-8 flex flex-col md:flex-row items-center justify-between gap-6 relative z-10">
           <div>
             <h2 className="text-2xl font-bold mb-2 flex items-center gap-2">
               <Share2 /> Indique e Ganhe
             </h2>
             <p className="text-purple-100 font-bold">
               Quanto mais indicações +10pts você ganha
             </p>
             {user.pendingReferrals && user.pendingReferrals.length > 0 && (
               <p className="text-xs mt-2 bg-purple-800/50 inline-block px-2 py-1 rounded text-purple-200">
                 {user.pendingReferrals.length} indicação(ões) em análise.
               </p>
             )}
           </div>
           <button 
             onClick={() => setShowReferralModal(true)}
             className="w-full md:w-auto px-6 py-3 bg-white text-purple-700 font-bold rounded-xl shadow-lg hover:bg-gray-100 transition active:scale-95 flex items-center justify-center gap-2"
           >
             <Send size={18} /> INDICAR AMIGO
           </button>
        </div>
      </div>

      {/* Rewards Grid */}
      <div>
        <h3 className="text-lg font-bold text-gray-800 mb-4 flex items-center gap-2">
          <Gift size={20} className="text-purple-600" />
          Recompensas Disponíveis
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
           {REWARDS.map((reward, idx) => {
             const unlocked = safePoints >= reward.pointsRequired;
             const isFinal = reward.pointsRequired === 500;
             const percent = Math.min((safePoints / reward.pointsRequired) * 100, 100);
             
             return (
               <div key={idx} className={`relative p-6 rounded-2xl border transition-all duration-300 group ${unlocked ? 'border-green-200 bg-white shadow-md hover:shadow-lg' : 'border-gray-100 bg-gray-50 opacity-90'}`}>
                  {unlocked && (
                    <div className="absolute -top-3 -right-3 bg-green-500 text-white p-1 rounded-full shadow-lg z-10">
                      <CheckCircle size={24} fill="white" className="text-green-500" />
                    </div>
                  )}
                  
                  <div className="flex items-start justify-between mb-4">
                    <div className={`p-4 rounded-2xl ${unlocked ? 'bg-blue-50 text-blue-600' : 'bg-gray-200 text-gray-500'}`}>
                      {getRewardIcon(reward.icon, 28)}
                    </div>
                    <span className={`font-mono font-bold text-lg ${unlocked ? 'text-gray-800' : 'text-gray-400'}`}>{reward.pointsRequired} pts</span>
                  </div>
                  
                  <h4 className="font-bold text-gray-800 text-lg mb-1">{reward.title}</h4>
                  <p className="text-sm text-gray-500 mb-4">{reward.description}</p>
                  
                  {isFinal && unlocked ? (
                    <button 
                     onClick={handleClaimReward500}
                     className="w-full py-3 bg-green-600 text-white font-bold rounded-xl shadow-lg hover:bg-green-700 transition transform hover:-translate-y-1 active:translate-y-0"
                    >
                      RESGATAR
                    </button>
                  ) : (
                    <div className="w-full h-2 bg-gray-200 rounded-full overflow-hidden">
                       <div className={`h-full ${unlocked ? 'bg-green-500' : 'bg-blue-500'}`} style={{ width: `${percent}%` }}></div>
                    </div>
                  )}
               </div>
             );
           })}
        </div>
      </div>

      {/* Recent Activity Mini-Feed */}
      <div>
        <h3 className="text-lg font-bold text-gray-800 mb-4 flex items-center gap-2">
          <Clock size={20} className="text-blue-600" />
          Últimas Atividades
        </h3>
        
        {history.length === 0 ? (
           <div className="bg-white rounded-xl p-8 text-center border border-gray-100 shadow-sm">
             <p className="text-gray-400">Nenhuma atividade registrada ainda.</p>
             <p className="text-sm text-gray-400 mt-1">Marque sua compra acima para começar!</p>
           </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
             {history.slice(0, 4).map((tx) => (
               <div key={tx.id} className="bg-white p-4 rounded-xl border border-gray-100 shadow-sm flex items-center gap-3">
                 <div className={`p-2 rounded-full ${tx.type === 'PURCHASE' ? 'bg-green-100 text-green-600' : tx.type === 'REDEEM' ? 'bg-red-100 text-red-500' : tx.type === 'REFERRAL' ? 'bg-purple-100 text-purple-600' : 'bg-yellow-100 text-yellow-600'}`}>
                   {tx.type === 'PURCHASE' ? <Check size={20} strokeWidth={3} /> : tx.type === 'REFERRAL' ? <Users size={20}/> : <Gift size={20} />}
                 </div>
                 <div>
                   <p className="font-bold text-gray-800 text-sm">{tx.description}</p>
                   <p className="text-xs text-gray-500">{new Date(tx.date).toLocaleDateString()}</p>
                 </div>
                 <div className={`ml-auto font-bold ${tx.points > 0 ? 'text-green-600' : 'text-red-500'}`}>
                   {tx.points > 0 ? '+' : ''}{tx.points}
                 </div>
               </div>
             ))}
          </div>
        )}
      </div>
    </div>
  );

  const HistoryView = () => (
    <div className="max-w-3xl animate-fade-in">
      <h2 className="text-2xl font-bold text-gray-800 mb-6">Seu Histórico de Pontos</h2>
      <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
        {history.length === 0 ? (
          <div className="p-12 text-center text-gray-500">
            <Clock size={48} className="mx-auto mb-4 text-gray-300" />
            <p>Seu histórico está vazio.</p>
          </div>
        ) : (
          <div className="divide-y divide-gray-100">
            {history.map((tx) => (
              <div key={tx.id} className="p-5 flex items-center hover:bg-gray-50 transition-colors group">
                {/* Visual "OK" Mark */}
                <div className={`
                  w-12 h-12 rounded-full flex items-center justify-center mr-4 shadow-sm border
                  ${tx.type === 'PURCHASE' ? 'bg-green-50 border-green-200 text-green-600' : 
                    tx.type === 'REDEEM' ? 'bg-red-50 border-red-200 text-red-500' : 
                    tx.type === 'REFERRAL' ? 'bg-purple-50 border-purple-200 text-purple-600' :
                    'bg-yellow-50 border-yellow-200 text-yellow-600'}
                `}>
                  {tx.type === 'PURCHASE' ? <Check size={24} strokeWidth={3} /> : 
                   tx.type === 'REDEEM' ? <Gift size={24} /> : 
                   tx.type === 'REFERRAL' ? <Users size={24} /> :
                   <Crown size={24} />}
                </div>

                <div className="flex-1">
                  <h4 className="font-bold text-gray-800">{tx.description}</h4>
                  <p className="text-sm text-gray-500">{new Date(tx.date).toLocaleDateString()} às {new Date(tx.date).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}</p>
                </div>

                <div className="text-right">
                  <span className={`text-lg font-bold ${tx.points > 0 ? 'text-green-600' : 'text-red-500'}`}>
                    {tx.points > 0 ? '+' : ''}{tx.points} pts
                  </span>
                  {(tx.type === 'PURCHASE' || tx.type === 'REFERRAL') && (
                    <div className="text-xs font-bold text-green-600 uppercase tracking-wide mt-1 bg-green-100 px-2 py-0.5 rounded-full inline-block">
                      OK
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );

  const PlansView = () => (
    <div className="animate-fade-in">
      <div className="text-center max-w-2xl mx-auto mb-10">
        <h2 className="text-3xl font-bold text-gray-800 mb-3">Planos VIP EquipeCompre+</h2>
        <p className="text-gray-500">Assine um de nossos planos e ganhe descontos exclusivos e pontos bônus todo mês.</p>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {[SubscriptionTier.BRONZE, SubscriptionTier.SILVER, SubscriptionTier.GOLD].map((tierKey) => {
          const tier = tierKey as SubscriptionTier;
          const data = TIERS[tier];
          const isCurrent = user.tier === tier;
          const isPending = user.pendingTier === tier;
          
          return (
            <div key={tier} className={`relative bg-white rounded-2xl shadow-lg border-2 flex flex-col items-center text-center overflow-hidden transition-transform hover:-translate-y-2 duration-300 ${isCurrent ? 'border-blue-500 ring-4 ring-blue-500/20' : 'border-gray-100'}`}>
              {isCurrent && (
                <div className="absolute top-0 w-full bg-blue-500 text-white text-xs font-bold py-1">
                  SEU PLANO ATUAL
                </div>
              )}
              
              <div className={`w-full p-6 ${data.color} ${isCurrent ? 'pt-10' : ''}`}>
                 <Crown size={40} className="mx-auto text-white/90" />
                 <h3 className="text-xl font-bold text-white mt-2">{data.name}</h3>
              </div>
              
              <div className="p-6 flex-1 flex flex-col w-full">
                <div className="mb-6">
                  <span className="text-sm text-gray-500 align-top">R$</span>
                  <span className="text-4xl font-extrabold text-gray-800">{Math.floor(data.price)}</span>
                  <span className="text-sm text-gray-500">,{data.price.toFixed(2).split('.')[1]}/mês</span>
                </div>

                <ul className="text-sm text-gray-600 space-y-4 mb-8 text-left w-full pl-4">
                  <li className="flex items-center gap-2">
                    <CheckCircle size={16} className="text-green-500 flex-shrink-0" />
                    <span>Ganhe <strong>+{data.bonusPoints} pontos</strong> na hora</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle size={16} className="text-green-500 flex-shrink-0" />
                    <span><strong>{data.discount}% DE DESCONTO</strong> em todas as compras</span>
                  </li>
                  {tier === SubscriptionTier.GOLD && (
                    <li className="flex items-center gap-2">
                      <CheckCircle size={16} className="text-green-500 flex-shrink-0" />
                      <span>🎁 Brinde exclusivo todo mês</span>
                    </li>
                  )}
                </ul>

                {/* Subscription Action Button */}
                <div className="mt-auto w-full">
                  {isCurrent ? (
                     <div className="py-3 bg-gray-100 text-gray-500 font-bold rounded-xl text-center cursor-default">
                       Plano Ativo
                     </div>
                  ) : isPending ? (
                    <div className="py-3 bg-yellow-100 text-yellow-700 font-bold rounded-xl text-center cursor-default border border-yellow-200 animate-pulse flex items-center justify-center gap-2">
                       <Clock size={16} /> Aguardando Aprovação
                    </div>
                  ) : (
                    <button 
                      onClick={() => handleSubscribe(tier)}
                      className="w-full py-3 bg-blue-50 border border-blue-200 rounded-xl text-center hover:bg-blue-100 transition-colors shadow-sm group"
                    >
                      <p className="text-blue-700 text-sm font-bold leading-tight flex items-center justify-center gap-2">
                        Assinar Agora <Send size={16} className="transform group-hover:translate-x-1 transition-transform"/>
                      </p>
                    </button>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );

  // Sidebar Item Component
  const NavItem = ({ view, label, icon: Icon, onClick }: { view?: ViewState, label: string, icon: any, onClick?: () => void }) => (
    <button
      onClick={() => {
        if (onClick) {
          onClick();
        } else if (view) {
          setCurrentView(view);
        }
        setMobileMenuOpen(false);
      }}
      className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl font-medium transition-all duration-200 ${
        (view && currentView === view)
          ? 'bg-blue-600 text-white shadow-lg shadow-blue-600/30' 
          : 'text-slate-400 hover:bg-slate-800 hover:text-white'
      }`}
    >
      <Icon size={20} />
      <span>{label}</span>
    </button>
  );

  return (
    <div className="flex min-h-screen bg-slate-50 font-sans text-slate-800 relative">
      
      {/* Sidebar (Desktop) */}
      <aside className={`fixed inset-y-0 left-0 z-50 w-64 bg-slate-900 text-white transform transition-transform duration-300 ease-in-out ${mobileMenuOpen ? 'translate-x-0' : '-translate-x-full'} md:translate-x-0 md:static md:flex-shrink-0`}>
        <div className="h-full flex flex-col p-6">
          <div className="mb-10 flex items-center justify-center">
            {/* Custom logo wrapper for dark bg */}
            <div className="bg-white/10 p-2 rounded-xl backdrop-blur-sm">
               <Logo size="md" /> 
            </div>
          </div>

          <nav className="flex-1 space-y-2">
            <NavItem view="HOME" label="Início" icon={Home} />
            <NavItem view="PROFILE" label="Meus Dados" icon={UserIcon} />
            <NavItem view="HISTORY" label="Extrato de Pontos" icon={Clock} />
            <NavItem view="PLANS" label="Assinatura VIP" icon={Crown} />
            <NavItem label="Saiba como Navegar" icon={Sparkles} onClick={() => setShowTutorial(true)} />
            <NavItem label="Instalar App" icon={Download} onClick={() => setShowInstallGuide(true)} />
          </nav>

          <div className="pt-6 border-t border-slate-800">
            <div className="flex items-center gap-3 px-2 mb-4">
              <div className="w-10 h-10 rounded-full bg-blue-500 flex items-center justify-center text-white font-bold">
                {user.fullName.charAt(0)}
              </div>
              <div className="overflow-hidden">
                <p className="text-sm font-bold truncate text-white">{user.fullName}</p>
                <p className="text-xs text-slate-400 truncate">{user.email}</p>
              </div>
            </div>
            {isImpersonating ? (
              <div className="px-4 py-2 text-yellow-300 text-xs font-bold text-center border border-yellow-500/30 rounded bg-yellow-900/20">
                MODO DE VISUALIZAÇÃO
              </div>
            ) : (
              <button 
                onClick={onLogout}
                className="w-full flex items-center gap-3 px-4 py-2 text-slate-400 hover:text-red-400 transition-colors"
              >
                <LogOut size={20} />
                <span>Sair da conta</span>
              </button>
            )}
          </div>
        </div>
      </aside>

      {/* Overlay for mobile sidebar */}
      {mobileMenuOpen && (
        <div 
          className="fixed inset-0 bg-black/50 z-40 md:hidden backdrop-blur-sm"
          onClick={() => setMobileMenuOpen(false)}
        />
      )}

      {/* Main Content Area */}
      <main className="flex-1 flex flex-col h-screen overflow-hidden relative">
        {/* Impersonation Banner */}
        {isImpersonating && (
          <div className="bg-yellow-500 text-yellow-900 px-4 py-2 font-bold text-center shadow-md z-[60] flex items-center justify-center gap-4">
            <span>👀 Você está visualizando como {user.fullName}</span>
            <button 
              onClick={onStopImpersonating}
              className="bg-white text-yellow-900 px-4 py-1 rounded-full text-sm hover:bg-yellow-50 transition shadow-sm flex items-center gap-1"
            >
              <ArrowLeft size={16}/> Voltar para Admin
            </button>
          </div>
        )}

        {/* Mobile Header */}
        <header className="md:hidden bg-white border-b border-gray-200 p-4 flex items-center justify-between z-30 sticky top-0">
          <button onClick={() => setMobileMenuOpen(true)} className="text-slate-600">
            <Menu size={24} />
          </button>
          <div className="scale-75 origin-center">
            <Logo size="sm" />
          </div>
          <div className="w-6" /> {/* spacer */}
        </header>

        {/* Scrollable Content */}
        <div className="flex-1 overflow-y-auto p-4 md:p-8 lg:p-12">
          <div className="max-w-6xl mx-auto">
             {currentView === 'HOME' && <HomeView />}
             {currentView === 'HISTORY' && <HistoryView />}
             {currentView === 'PLANS' && <PlansView />}
             {currentView === 'PROFILE' && <ProfileView />}
          </div>
        </div>
      </main>
      
      <TutorialModal />
      <InstallGuideModal />
      <ReferralModal />
    </div>
  );
};

export default ClientDashboard;