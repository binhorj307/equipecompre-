import React, { useState } from 'react';
import { User, UserRole, SubscriptionTier } from '../types';
import { saveUser, checkUsernameExists } from '../services/authService';
import { Loader2, Search, Eye, EyeOff } from 'lucide-react';

interface Props {
  onRegister: (user: User) => void; 
  onCancel: () => void;
}

const BR_STATES = [
  'AC', 'AL', 'AP', 'AM', 'BA', 'CE', 'DF', 'ES', 'GO', 'MA', 'MT', 'MS',
  'MG', 'PA', 'PB', 'PR', 'PE', 'PI', 'RJ', 'RN', 'RS', 'RO', 'RR', 'SC',
  'SP', 'SE', 'TO'
];

const RegisterForm: React.FC<Props> = ({ onRegister, onCancel }) => {
  const [loading, setLoading] = useState(false);
  const [loadingCep, setLoadingCep] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);

  const [formData, setFormData] = useState({
    username: '',
    password: '',
    confirmPassword: '',
    cpf: '',
    fullName: '',
    email: '',
    phone: '',
    street: '',
    number: '',
    complement: '',
    district: '',
    city: '',
    uf: '',
    cep: ''
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleCepChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    // Only numbers
    const rawCep = e.target.value;
    setFormData(prev => ({ ...prev, cep: rawCep }));
    
    const cleanCep = rawCep.replace(/\D/g, '');

    if (cleanCep.length === 8) {
      setLoadingCep(true);
      try {
        const response = await fetch(`https://viacep.com.br/ws/${cleanCep}/json/`);
        const data = await response.json();
        
        if (!data.erro) {
          setFormData(prev => ({
            ...prev,
            street: data.logradouro,
            district: data.bairro,
            city: data.localidade,
            uf: data.uf,
            // Optionally focus on number field here if we had refs
          }));
        }
      } catch (error) {
        console.error("Erro ao buscar CEP", error);
      } finally {
        setLoadingCep(false);
      }
    }
  };

  const sendWhatsAppNotification = (user: User) => {
    const message = `
*Novo Cadastro EquipeCompre+* 🛍️
Nome: ${user.fullName}
CPF: ${user.cpf}
Telefone: ${user.phone}
Email: ${user.email}
Endereço: ${user.address.street}, ${user.address.number} - ${user.address.district}
    `.trim();
    
    // Using the number provided in prompt
    const phone = "5521985415117"; 
    const url = `https://wa.me/${phone}?text=${encodeURIComponent(message)}`;
    window.open(url, '_blank');
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    // Basic Validation
    if (formData.password !== formData.confirmPassword) {
      alert("Senhas não conferem!");
      setLoading(false);
      return;
    }

    const username = formData.username.trim();

    if (checkUsernameExists(username)) {
      alert("Nome de usuário já existe.");
      setLoading(false);
      return;
    }

    // Simulate API delay
    await new Promise(r => setTimeout(r, 1000));

    const newUser: User = {
      id: Date.now().toString(),
      username: username,
      password: formData.password,
      role: UserRole.CLIENT,
      points: 0,
      tier: SubscriptionTier.FREE,
      joinDate: new Date().toISOString(),
      cpf: formData.cpf,
      fullName: formData.fullName,
      email: formData.email,
      phone: formData.phone,
      address: {
        street: formData.street,
        number: formData.number,
        complement: formData.complement,
        district: formData.district,
        city: formData.city,
        uf: formData.uf,
        cep: formData.cep
      },
      history: []
    };

    saveUser(newUser);
    
    // Notify Admin via WhatsApp
    sendWhatsAppNotification(newUser);

    alert("Cadastro realizado com sucesso! Bem-vindo ao EquipeCompre+.");
    onRegister(newUser);
    setLoading(false);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4 text-left">
      <h2 className="text-xl font-bold text-blue-600 mb-4">Criar Nova Conta</h2>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="col-span-1 md:col-span-2 bg-blue-50 p-4 rounded-lg border border-blue-100 shadow-sm">
          <h3 className="font-semibold text-blue-800 mb-2">Dados de Acesso</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
             <div>
               <label className="text-xs text-blue-600 font-bold ml-1">Usuário</label>
               <input required name="username" placeholder="Nome de Usuário" className="w-full p-2 border border-gray-300 rounded bg-white focus:ring-2 focus:ring-blue-500 outline-none" onChange={handleChange} />
             </div>
             <div className="hidden md:block"></div>
             <div className="relative">
               <label className="text-xs text-blue-600 font-bold ml-1">Senha</label>
               <input required type={showPassword ? "text" : "password"} name="password" placeholder="Senha" className="w-full p-2 border border-gray-300 rounded bg-white focus:ring-2 focus:ring-blue-500 outline-none pr-10" onChange={handleChange} />
               <button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute right-2 top-8 text-gray-500 hover:text-blue-600">
                  {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
               </button>
             </div>
             <div className="relative">
               <label className="text-xs text-blue-600 font-bold ml-1">Confirmar Senha</label>
               <input required type={showConfirmPassword ? "text" : "password"} name="confirmPassword" placeholder="Confirmar Senha" className="w-full p-2 border border-gray-300 rounded bg-white focus:ring-2 focus:ring-blue-500 outline-none pr-10" onChange={handleChange} />
               <button type="button" onClick={() => setShowConfirmPassword(!showConfirmPassword)} className="absolute right-2 top-8 text-gray-500 hover:text-blue-600">
                  {showConfirmPassword ? <EyeOff size={16} /> : <Eye size={16} />}
               </button>
             </div>
          </div>
        </div>

        <div className="col-span-1 md:col-span-2">
           <label className="text-xs text-gray-500 font-bold ml-1">Nome Completo</label>
           <input required name="fullName" placeholder="Ex: João da Silva" className="w-full p-2 border border-gray-300 rounded bg-white focus:ring-2 focus:ring-blue-500 outline-none" onChange={handleChange} />
        </div>
        
        <div>
           <label className="text-xs text-gray-500 font-bold ml-1">CPF</label>
           <input required name="cpf" placeholder="000.000.000-00" className="w-full p-2 border border-gray-300 rounded bg-white focus:ring-2 focus:ring-blue-500 outline-none" onChange={handleChange} />
        </div>
        
        <div>
           <label className="text-xs text-gray-500 font-bold ml-1">Telefone / WhatsApp</label>
           <input required name="phone" placeholder="(21) 90000-0000" className="w-full p-2 border border-gray-300 rounded bg-white focus:ring-2 focus:ring-blue-500 outline-none" onChange={handleChange} />
        </div>

        <div className="col-span-1 md:col-span-2">
           <label className="text-xs text-gray-500 font-bold ml-1">Email</label>
           <input required name="email" type="email" placeholder="seu@email.com" className="w-full p-2 border border-gray-300 rounded bg-white focus:ring-2 focus:ring-blue-500 outline-none" onChange={handleChange} />
        </div>
        
        <div className="col-span-1 md:col-span-2 mt-4 border-t pt-4">
          <h3 className="font-semibold text-gray-700 mb-2 flex items-center gap-2">
            <span className="bg-blue-100 p-1 rounded text-blue-600"><Search size={16}/></span>
            Endereço de Entrega
          </h3>
        </div>
        
        <div className="relative col-span-1 md:col-span-2">
          <label className="text-xs text-gray-500 font-bold ml-1">CEP (Busca Automática)</label>
          <div className="relative">
            <input 
              required 
              name="cep" 
              placeholder="00000-000" 
              className="w-full p-2 border border-gray-300 rounded bg-white pr-10 focus:ring-2 focus:ring-blue-500 outline-none" 
              value={formData.cep}
              onChange={handleCepChange} 
              maxLength={9}
            />
            <div className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400">
              {loadingCep ? <Loader2 className="animate-spin text-blue-500" size={16} /> : <Search size={16} />}
            </div>
          </div>
        </div>

        <div className="col-span-1 md:col-span-2 flex gap-2">
           <div className="flex-grow">
             <label className="text-xs text-gray-500 font-bold ml-1">Logradouro</label>
             <input required name="street" value={formData.street} placeholder="Rua, Av..." className="w-full p-2 border border-gray-300 rounded bg-white focus:ring-2 focus:ring-blue-500 outline-none" onChange={handleChange} />
           </div>
           <div className="w-24">
             <label className="text-xs text-gray-500 font-bold ml-1">Número</label>
             <input required name="number" value={formData.number} placeholder="Nº" className="w-full p-2 border border-gray-300 rounded bg-white focus:ring-2 focus:ring-blue-500 outline-none" onChange={handleChange} />
           </div>
        </div>

        <div className="col-span-1 md:col-span-2">
           <label className="text-xs text-gray-500 font-bold ml-1">Complemento</label>
           <input name="complement" value={formData.complement} placeholder="Apto, Bloco..." className="w-full p-2 border border-gray-300 rounded bg-white focus:ring-2 focus:ring-blue-500 outline-none" onChange={handleChange} />
        </div>

        <div>
           <label className="text-xs text-gray-500 font-bold ml-1">Bairro</label>
           <input required name="district" value={formData.district} placeholder="Bairro" className="w-full p-2 border border-gray-300 rounded bg-white focus:ring-2 focus:ring-blue-500 outline-none" onChange={handleChange} />
        </div>
        
        <div>
           <label className="text-xs text-gray-500 font-bold ml-1">Cidade</label>
           <input required name="city" value={formData.city} placeholder="Cidade" className="w-full p-2 border border-gray-300 rounded bg-white focus:ring-2 focus:ring-blue-500 outline-none" onChange={handleChange} />
        </div>
        
        <div className="col-span-1 md:col-span-2">
           <label className="text-xs text-gray-500 font-bold ml-1">Estado (UF)</label>
            <select 
              required 
              name="uf" 
              value={formData.uf} 
              onChange={handleChange}
              className="w-full p-2 border border-gray-300 rounded bg-white text-gray-700 focus:ring-2 focus:ring-blue-500 outline-none"
            >
              <option value="">Selecione o Estado</option>
              {BR_STATES.map(uf => (
                <option key={uf} value={uf}>{uf}</option>
              ))}
            </select>
        </div>

      </div>

      <div className="flex gap-2 pt-6">
        <button type="button" onClick={onCancel} className="w-1/3 p-3 text-gray-600 bg-gray-200 rounded-lg hover:bg-gray-300 font-bold transition">
          Voltar
        </button>
        <button type="submit" disabled={loading} className="w-2/3 p-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-bold flex justify-center items-center gap-2 shadow-lg transition transform active:scale-95">
          {loading ? <Loader2 className="animate-spin" /> : 'CONFIRMAR CADASTRO'}
        </button>
      </div>
    </form>
  );
};

export default RegisterForm;