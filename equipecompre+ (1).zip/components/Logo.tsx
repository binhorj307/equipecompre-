import React from 'react';
import { ShoppingBag, Plus } from 'lucide-react';

export const Logo: React.FC<{ size?: 'sm' | 'md' | 'lg' }> = ({ size = 'md' }) => {
  const dim = size === 'sm' ? 24 : size === 'md' ? 40 : 60;
  // Sizes for text
  const textEquipe = size === 'sm' ? 'text-lg' : size === 'md' ? 'text-2xl' : 'text-5xl';
  const textCompre = size === 'sm' ? 'text-xl' : size === 'md' ? 'text-3xl' : 'text-6xl';
  const subtitleSize = size === 'sm' ? 'text-[0.4rem]' : size === 'md' ? 'text-[0.6rem]' : 'text-sm';

  return (
    <div className="flex items-center gap-2 select-none justify-center">
      <div className="flex flex-col items-center leading-none">
        <div className="flex items-baseline gap-1">
          {/* Equipe in Blue Sans-Serif */}
          <span className={`${textEquipe} font-bold text-[#007bff] tracking-tight`}>
            Equipe
          </span>
          
          {/* Compre in Black Cursive */}
          <span className={`${textCompre} font-cursive text-black transform -rotate-2 origin-bottom-left`}>
            Compre
          </span>

          {/* Icon Integrated */}
          <div className="relative text-[#007bff] ml-1">
            <ShoppingBag size={dim} strokeWidth={1.5} />
            <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 text-[#007bff] bg-white rounded-full p-0.5 shadow-sm border border-blue-100">
              <Plus size={dim * 0.4} strokeWidth={4} />
            </div>
          </div>
        </div>
        
        {/* Slogan */}
        <span className={`${subtitleSize} text-gray-500 uppercase tracking-[0.2em] font-light mt-1 w-full text-center border-t border-gray-200 pt-1`}>
          Compre mais pague menos
        </span>
      </div>
    </div>
  );
};