import React, { useState } from 'react';
import { User, Transaction, TIERS, SubscriptionTier, UserRole, PendingReferral } from '../types';
import { getUsers, updateUser, saveUser, deleteUser, checkUsernameExists, importUsersData } from '../services/authService';
import { generateAdminInsights } from '../services/geminiService';
import { Logo } from './Logo';
import ClientDashboard from './ClientDashboard';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from 'recharts';
import { 
  Search, 
  UserPlus, 
  TrendingUp, 
  Award, 
  Sparkles, 
  Loader2, 
  Check, 
  AlertTriangle, 
  Home,
  LogOut,
  User as UserIcon,
  Menu,
  Save,
  Users,
  Pencil,
  X,
  Eye,
  EyeOff,
  Minus,
  ShieldAlert,
  Coins,
  Trash2,
  ShoppingBag,
  Download,
  Upload,
  Database,
  MonitorPlay
} from 'lucide-react';

interface Props {
  currentUser: User;
  onLogout: () => void;
  onUserUpdate: (user: User) => void;
}

const BR_STATES = [
  'AC', 'AL', 'AP', 'AM', 'BA', 'CE', 'DF', 'ES', 'GO', 'MA', 'MT', 'MS',
  'MG', 'PA', 'PB', 'PR', 'PE', 'PI', 'RJ', 'RN', 'RS', 'RO', 'RR', 'SC',
  'SP', 'SE', 'TO'
];

type ViewState = 'DASHBOARD' | 'PROFILE';

const AdminDashboard: React.FC<Props> = ({ currentUser, onLogout, onUserUpdate }) => {
  const [users, setUsers] = useState<User[]>(getUsers());
  const [searchTerm, setSearchTerm] = useState('');
  const [insight, setInsight] = useState<string | null>(null);
  const [loadingInsight, setLoadingInsight] = useState(false);
  const [currentView, setCurrentView] = useState<ViewState>('DASHBOARD');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  
  // Client Edit State
  const [editingClient, setEditingClient] = useState<Partial<User> | null>(null);
  const [isCreating, setIsCreating] = useState(false);
  
  // Referral Management State
  const [managingReferralsUser, setManagingReferralsUser] = useState<User | null>(null);

  // Impersonation State
  const [impersonatingUser, setImpersonatingUser] = useState<User | null>(null);

  // If impersonating, render the ClientDashboard instead
  if (impersonatingUser) {
    return (
      <ClientDashboard 
        user={impersonatingUser} 
        onLogout={onLogout} 
        onUserUpdate={(updatedUser) => {
          // CRITICAL: Do NOT call the parent prop onUserUpdate(updatedUser) here.
          // That would update the MAIN APP session user (the Admin) to be the Client, effectively logging the Admin out.
          
          // 1. Update the database persistently
          updateUser(updatedUser);
          
          // 2. Refresh the local users list so the Admin Dashboard is up to date when we return
          setUsers(getUsers());
          
          // 3. Update the currently impersonated user state to reflect changes in the UI immediately
          setImpersonatingUser(updatedUser);
        }}
        isImpersonating={true}
        onStopImpersonating={() => setImpersonatingUser(null)}
      />
    );
  }

  // Show ALL users matching search, so Super Admin can edit other Admins too.
  const filteredUsers = users.filter(u => 
    (u.fullName.toLowerCase().includes(searchTerm.toLowerCase()) || 
     u.cpf.includes(searchTerm) || 
     u.username.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  const handleAdjustPoints = (e: React.MouseEvent, targetUser: User, amount: number) => {
    e.preventDefault(); // Prevent any default button behavior
    
    // Ensure points are treated as numbers
    const currentPoints = Number(targetUser.points) || 0;
    
    // Safety check for negative balance
    if (amount < 0 && currentPoints <= 0) {
      return; 
    }

    let description = '';
    
    if (amount > 0) {
      description = 'Compra Confirmada';
    } else {
      description = 'Remoção de Pontos';
      // Calculate potential new points
      if (currentPoints + amount < 0) {
        // If removing more than available, just zero it out
        if (!confirm(`O usuário tem apenas ${currentPoints} pontos. Deseja zerar o saldo?`)) {
          return;
        }
      }
    }
    
    // Calculate new points, ensuring it doesn't drop below zero
    const newPoints = Math.max(0, currentPoints + amount);
    
    const newTransaction: Transaction = {
      id: Date.now().toString(),
      date: new Date().toISOString(),
      points: amount,
      type: amount > 0 ? 'PURCHASE' : 'REDEEM',
      description: description
    };

    const currentHistory = targetUser.history || [];
    const updatedUser = { 
      ...targetUser, 
      points: newPoints,
      history: [newTransaction, ...currentHistory]
    };
    
    updateUser(updatedUser);
    setUsers(getUsers());
  };

  const handleApprovePurchase = (targetUser: User) => {
    // 1. Add 10 points - FORCE NUMBER TYPE
    const currentPoints = Number(targetUser.points) || 0;
    const newPoints = currentPoints + 10;
    
    const newTransaction: Transaction = {
      id: Date.now().toString(),
      date: new Date().toISOString(),
      points: 10,
      type: 'PURCHASE',
      description: 'Compra Confirmada (Solicitação)'
    };

    const updatedUser = {
      ...targetUser,
      points: newPoints,
      history: [newTransaction, ...(targetUser.history || [])],
      pendingPurchase: false // Clear the flag
    };

    updateUser(updatedUser);
    setUsers(getUsers());

    // 2. Notify Client via WhatsApp - SUPER MOTIVATIONAL MESSAGE
    const message = `
*PARABÉNS!!* 🚀🎉

Olá, *${targetUser.fullName.split(' ')[0]}*! Você é incrível! 🤩

Sua compra foi confirmada com sucesso pela equipe.
Você acaba de dar mais um passo rumo ao seu próximo prêmio!

➕ *GANHOU:* 10 PONTOS
💰 *SALDO ATUAL:* ${newPoints} pontos

Adoramos ter você como cliente. Continue brilhando e acumulando pontos, porque você merece o melhor!
Vamos com tudo para a próxima conquista! 💪✨

_EquipeCompre+_
    `.trim();
    
    const cleanPhone = targetUser.phone.replace(/\D/g, '');
    const phoneWithCountry = cleanPhone.startsWith('55') ? cleanPhone : `55${cleanPhone}`;
    const url = `https://wa.me/${phoneWithCountry}?text=${encodeURIComponent(message)}`;
    
    window.open(url, '_blank');
  };
  
  const handleApproveReferral = (user: User, referral: PendingReferral) => {
    // 1. Add 10 points
    const currentPoints = Number(user.points) || 0;
    const newPoints = currentPoints + 10;
    
    const newTransaction: Transaction = {
      id: Date.now().toString(),
      date: new Date().toISOString(),
      points: 10,
      type: 'REFERRAL',
      description: `Indicação: ${referral.name}`
    };

    // Remove this referral from pending
    const remainingReferrals = (user.pendingReferrals || []).filter(r => r.id !== referral.id);

    const updatedUser = {
      ...user,
      points: newPoints,
      history: [newTransaction, ...(user.history || [])],
      pendingReferrals: remainingReferrals
    };

    updateUser(updatedUser);
    setUsers(getUsers());
    setManagingReferralsUser(updatedUser); // Update local modal state

    // 2. Notify Client
    const message = `
*INDICAÇÃO APROVADA!* 🗣️✅

Parabéns, ${user.fullName.split(' ')[0]}!

Sua indicação de *${referral.name}* foi confirmada com sucesso.

➕ *GANHOU:* 10 PONTOS BÔNUS
💰 *SALDO ATUAL:* ${newPoints} pontos

Continue indicando e ganhando! Obrigado por fazer a família EquipeCompre+ crescer. 💙
    `.trim();
    
    const cleanPhone = user.phone.replace(/\D/g, '');
    const phoneWithCountry = cleanPhone.startsWith('55') ? cleanPhone : `55${cleanPhone}`;
    const url = `https://wa.me/${phoneWithCountry}?text=${encodeURIComponent(message)}`;
    
    window.open(url, '_blank');
  };

  const handleDeleteUser = (userId: string) => {
    if (confirm("Tem certeza que deseja excluir este usuário? Esta ação não pode ser desfeita.")) {
      deleteUser(userId);
      setUsers(getUsers());
    }
  };

  const handleCreateUser = () => {
    setIsCreating(true);
    setEditingClient({
      username: '',
      password: '',
      fullName: '',
      cpf: '',
      email: '',
      phone: '',
      role: UserRole.CLIENT,
      tier: SubscriptionTier.FREE,
      points: 0,
      address: {
        street: '', number: '', district: '', city: '', uf: '', cep: ''
      },
      history: []
    });
  };

  const handleApproveTier = (targetUser: User) => {
    if (!targetUser.pendingTier) return;

    const newTier = targetUser.pendingTier;
    const tierData = TIERS[newTier];
    const isDowngrade = newTier === SubscriptionTier.FREE;

    // Add bonus points if it's an upgrade
    let newHistory = targetUser.history || [];
    let newPoints = Number(targetUser.points) || 0;

    if (!isDowngrade && tierData.bonusPoints > 0) {
       const bonusTx: Transaction = {
          id: Date.now().toString(),
          date: new Date().toISOString(),
          points: tierData.bonusPoints,
          type: 'BONUS',
          description: `Bônus Assinatura ${tierData.name}`
       };
       newHistory = [bonusTx, ...newHistory];
       newPoints += tierData.bonusPoints;
    }

    const updatedUser: User = {
      ...targetUser,
      tier: newTier,
      points: newPoints,
      history: newHistory,
      pendingTier: undefined // Clear pending
    };

    updateUser(updatedUser);
    setUsers(getUsers());

    // NOTIFY CLIENT via WhatsApp
    const message = `
*CONFIRMAÇÃO DE ASSINATURA - EquipeCompre+* ✅

Olá ${targetUser.fullName.split(' ')[0]}!

Sua assinatura do plano *${tierData.name}* foi APROVADA com sucesso!
Agora você tem ${tierData.discount}% de desconto em todas as compras.

Aproveite! 🛍️
    `.trim();
    
    const cleanPhone = targetUser.phone.replace(/\D/g, '');
    const phoneWithCountry = cleanPhone.startsWith('55') ? cleanPhone : `55${cleanPhone}`;
    const url = `https://wa.me/${phoneWithCountry}?text=${encodeURIComponent(message)}`;
    
    window.open(url, '_blank');
  };

  const handleGenerateInsight = async () => {
    setLoadingInsight(true);
    const result = await generateAdminInsights(users);
    setInsight(result);
    setLoadingInsight(false);
  };

  const handleExportBackup = () => {
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(users));
    const downloadAnchorNode = document.createElement('a');
    downloadAnchorNode.setAttribute("href", dataStr);
    downloadAnchorNode.setAttribute("download", `backup_equipecompre_${new Date().toISOString().split('T')[0]}.json`);
    document.body.appendChild(downloadAnchorNode);
    downloadAnchorNode.click();
    downloadAnchorNode.remove();
  };

  const handleImportBackup = (event: React.ChangeEvent<HTMLInputElement>) => {
    const fileReader = new FileReader();
    if (event.target.files && event.target.files.length > 0) {
        fileReader.readAsText(event.target.files[0], "UTF-8");
        fileReader.onload = (e) => {
            if (e.target?.result) {
                const success = importUsersData(e.target.result as string);
                if (success) {
                    setUsers(getUsers());
                    alert("Backup restaurado com sucesso! Seus dados foram recuperados.");
                } else {
                    alert("Erro ao restaurar backup. O arquivo selecionado não é válido.");
                }
            }
        };
    }
  };

  // Chart Data Preparation
  const tierData = [
    { name: 'Bronze', count: users.filter(u => u.tier === 'BRONZE').length },
    { name: 'Prata', count: users.filter(u => u.tier === 'SILVER').length },
    { name: 'Ouro', count: users.filter(u => u.tier === 'GOLD').length },
    { name: 'Free', count: users.filter(u => u.tier === 'FREE').length },
  ];

  // Referral Management Modal
  const ManageReferralsModal = () => {
    if (!managingReferralsUser) return null;

    const referrals = managingReferralsUser.pendingReferrals || [];

    return (
      <div className="fixed inset-0 z-[75] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fade-in">
        <div className="bg-white w-full max-w-lg rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[80vh]">
          <div className="bg-purple-600 p-4 flex justify-between items-center text-white">
            <h3 className="font-bold text-lg flex items-center gap-2">
              <Users size={18} /> Indicações de {managingReferralsUser.fullName.split(' ')[0]}
            </h3>
            <button onClick={() => setManagingReferralsUser(null)} className="hover:bg-purple-700 p-1 rounded-full"><X size={20}/></button>
          </div>
          
          <div className="p-6 overflow-y-auto custom-scrollbar">
            {referrals.length === 0 ? (
              <p className="text-gray-500 text-center py-4">Nenhuma indicação pendente.</p>
            ) : (
              <div className="space-y-3">
                {referrals.map((referral) => (
                  <div key={referral.id} className="border border-purple-100 bg-purple-50 p-4 rounded-xl flex items-center justify-between">
                    <div>
                      <p className="font-bold text-gray-800">{referral.name}</p>
                      <p className="text-sm text-gray-500">{referral.phone}</p>
                      <p className="text-xs text-gray-400 mt-1">{new Date(referral.date).toLocaleDateString()}</p>
                    </div>
                    <button 
                      onClick={() => handleApproveReferral(managingReferralsUser, referral)}
                      className="bg-green-600 text-white px-3 py-2 rounded-lg font-bold text-sm shadow-md hover:bg-green-700 transition flex items-center gap-1"
                    >
                      <Check size={16} /> Aprovar
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    );
  };

  // Client Edit Component (Modal)
  const EditClientModal = () => {
    if (!editingClient) return null;
    
    // We cast to User for the form state, but for creation some IDs are missing initially
    // @ts-ignore
    const [formData, setFormData] = useState<User>({ ...editingClient });
    const [loadingCep, setLoadingCep] = useState(false);
    const [showPassword, setShowPassword] = useState(false);

    const isSuperAdmin = !isCreating && editingClient.username === 'admin';

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
      // @ts-ignore
      setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    const handleAddressChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
       setFormData({
         ...formData,
         address: { ...formData.address, [e.target.name]: e.target.value }
       });
    };

    const handleCepChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
      const rawCep = e.target.value;
      setFormData(prev => ({ ...prev, address: { ...prev.address, cep: rawCep } }));
      const cleanCep = rawCep.replace(/\D/g, '');

      if (cleanCep.length === 8) {
        setLoadingCep(true);
        try {
          const response = await fetch(`https://viacep.com.br/ws/${cleanCep}/json/`);
          const data = await response.json();
          if (!data.erro) {
            setFormData(prev => ({
              ...prev,
              address: {
                ...prev.address,
                street: data.logradouro,
                district: data.bairro,
                city: data.localidade,
                uf: data.uf,
              }
            }));
          }
        } catch (error) {
          console.error("Erro CEP", error);
        } finally {
          setLoadingCep(false);
        }
      }
    };

    const handleSaveClient = (e: React.FormEvent) => {
      e.preventDefault();
      
      // Validate unique username
      if (checkUsernameExists(formData.username, isCreating ? undefined : editingClient.id)) {
        alert("Nome de usuário já existe.");
        return;
      }

      if (isCreating) {
        const newUser: User = {
          ...formData,
          id: Date.now().toString(),
          joinDate: new Date().toISOString(),
          points: Number(formData.points) || 0,
          history: []
        };
        saveUser(newUser);
        alert("Usuário criado com sucesso!");
      } else {
        const updatedUser = {
            ...formData,
            points: Number(formData.points) || 0
        };
        updateUser(updatedUser);
        alert("Dados atualizados com sucesso!");
      }

      setUsers(getUsers());
      setEditingClient(null);
      setIsCreating(false);
    };

    return (
      <div className="fixed inset-0 z-[70] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fade-in">
        <div className="bg-white w-full max-w-2xl rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
          <div className="bg-blue-600 p-4 flex justify-between items-center text-white">
            <h3 className="font-bold text-lg flex items-center gap-2">
              {isCreating ? <UserPlus size={18} /> : <Pencil size={18} />} 
              {isCreating ? 'Novo Usuário' : `Editando: ${editingClient.fullName}`}
            </h3>
            <button onClick={() => { setEditingClient(null); setIsCreating(false); }} className="hover:bg-blue-700 p-1 rounded-full"><X size={20}/></button>
          </div>
          
          <form onSubmit={handleSaveClient} className="p-6 overflow-y-auto custom-scrollbar space-y-4">
             {/* Account Info */}
             <div className="bg-blue-50 p-4 rounded-xl space-y-3">
               <div className="flex justify-between items-center mb-2">
                 <h4 className="text-sm font-bold text-blue-800 uppercase">Acesso & Permissões</h4>
                 {isSuperAdmin && (
                   <span className="text-xs bg-red-100 text-red-600 px-2 py-1 rounded font-bold border border-red-200">SUPER ADMIN</span>
                 )}
               </div>
               
               <div className="grid grid-cols-2 gap-4">
                 <div>
                   <label className="text-xs font-bold text-gray-500">Usuário</label>
                   <input required name="username" value={formData.username} onChange={handleChange} className="w-full p-2 border rounded" placeholder="Login" />
                 </div>
                 
                 {/* Role Selector */}
                 <div>
                   <label className="text-xs font-bold text-gray-500 flex items-center gap-1">
                     Função (Role)
                     {isSuperAdmin && <ShieldAlert size={12} className="text-red-500"/>}
                   </label>
                   <select 
                     name="role" 
                     value={formData.role} 
                     onChange={handleChange}
                     disabled={isSuperAdmin} // Prevent changing Super Admin role
                     className={`w-full p-2 border rounded font-bold ${formData.role === 'ADMIN' ? 'text-purple-600 bg-purple-50 border-purple-200' : 'text-gray-700'}`}
                   >
                     <option value={UserRole.CLIENT}>Cliente</option>
                     <option value={UserRole.ADMIN}>Administrador</option>
                   </select>
                 </div>

                 {/* Editable Points Field */}
                 <div className="col-span-2 border-t border-blue-200 pt-3 mt-1">
                    <label className="text-sm font-bold text-blue-700 flex items-center gap-1 mb-1">
                      <Coins size={16} /> Saldo de Pontos
                    </label>
                    <div className="flex items-center gap-2">
                      <input 
                        type="number" 
                        name="points" 
                        value={formData.points} 
                        onChange={handleChange} 
                        className="w-full p-2 border border-blue-300 rounded font-mono font-bold text-lg text-blue-700" 
                      />
                      <span className="text-xs text-gray-500 max-w-[150px]">
                        Defina o saldo inicial ou ajuste manualmente.
                      </span>
                    </div>
                 </div>

                 <div className="relative col-span-2">
                   <label className="text-xs font-bold text-gray-500">Senha</label>
                   <input required type={showPassword ? "text" : "password"} name="password" value={formData.password || ''} onChange={handleChange} className="w-full p-2 border rounded pr-10" placeholder="Senha de acesso" />
                   <button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute right-2 top-8 text-gray-400 hover:text-blue-600">
                     {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                   </button>
                 </div>
               </div>
             </div>

             {/* Personal Info */}
             <div className="space-y-3">
                <h4 className="text-sm font-bold text-gray-700 uppercase">Dados Pessoais</h4>
                <div>
                   <label className="text-xs font-bold text-gray-500">Nome Completo</label>
                   <input required name="fullName" value={formData.fullName} onChange={handleChange} className="w-full p-2 border rounded" placeholder="Nome completo" />
                </div>
                <div className="grid grid-cols-2 gap-4">
                   <div>
                     <label className="text-xs font-bold text-gray-500">CPF</label>
                     <input required name="cpf" value={formData.cpf} onChange={handleChange} className="w-full p-2 border rounded" placeholder="000.000.000-00" />
                   </div>
                   <div>
                     <label className="text-xs font-bold text-gray-500">Telefone</label>
                     <input required name="phone" value={formData.phone} onChange={handleChange} className="w-full p-2 border rounded" placeholder="(21) 90000-0000" />
                   </div>
                </div>
                <div>
                   <label className="text-xs font-bold text-gray-500">Email</label>
                   <input required name="email" value={formData.email} onChange={handleChange} className="w-full p-2 border rounded" placeholder="email@exemplo.com" />
                </div>
             </div>

             {/* Address */}
             <div className="space-y-3 border-t pt-3">
                <h4 className="text-sm font-bold text-gray-700 uppercase">Endereço</h4>
                <div className="grid grid-cols-3 gap-3">
                   <div className="col-span-1">
                     <label className="text-xs font-bold text-gray-500">CEP</label>
                     <div className="relative">
                       <input required name="cep" value={formData.address?.cep || ''} onChange={handleCepChange} className="w-full p-2 border rounded" maxLength={9} placeholder="00000-000"/>
                       {loadingCep && <Loader2 size={12} className="absolute right-2 top-3 animate-spin text-blue-500" />}
                     </div>
                   </div>
                   <div className="col-span-2">
                     <label className="text-xs font-bold text-gray-500">Rua</label>
                     <input required name="street" value={formData.address?.street || ''} onChange={handleAddressChange} className="w-full p-2 border rounded" />
                   </div>
                   <div className="col-span-1">
                     <label className="text-xs font-bold text-gray-500">Número</label>
                     <input required name="number" value={formData.address?.number || ''} onChange={handleAddressChange} className="w-full p-2 border rounded" />
                   </div>
                   <div className="col-span-2">
                     <label className="text-xs font-bold text-gray-500">Complemento</label>
                     <input name="complement" value={formData.address?.complement || ''} onChange={handleAddressChange} className="w-full p-2 border rounded" />
                   </div>
                   <div className="col-span-2">
                     <label className="text-xs font-bold text-gray-500">Bairro</label>
                     <input required name="district" value={formData.address?.district || ''} onChange={handleAddressChange} className="w-full p-2 border rounded" />
                   </div>
                   <div className="col-span-1">
                     <label className="text-xs font-bold text-gray-500">Cidade</label>
                     <input required name="city" value={formData.address?.city || ''} onChange={handleAddressChange} className="w-full p-2 border rounded" />
                   </div>
                   <div className="col-span-2">
                     <label className="text-xs font-bold text-gray-500">UF</label>
                     <select name="uf" value={formData.address?.uf || ''} onChange={handleAddressChange} className="w-full p-2 border rounded">
                       <option value="">UF</option>
                       {BR_STATES.map(s => <option key={s} value={s}>{s}</option>)}
                     </select>
                   </div>
                </div>
             </div>
          </form>

          <div className="p-4 border-t bg-gray-50 flex justify-end gap-2">
            <button onClick={() => { setEditingClient(null); setIsCreating(false); }} className="px-4 py-2 text-gray-600 font-bold hover:bg-gray-200 rounded">Cancelar</button>
            <button onClick={handleSaveClient} className="px-6 py-2 bg-blue-600 text-white font-bold hover:bg-blue-700 rounded shadow">
               {isCreating ? 'Criar Usuário' : 'Salvar Alterações'}
            </button>
          </div>
        </div>
      </div>
    );
  };

  const DashboardView = () => (
    <div className="space-y-6 animate-fade-in">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Stats Column */}
          <div className="lg:col-span-2 space-y-6">
             {/* Quick Stats */}
             <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
               <div className="bg-white p-6 rounded-xl shadow-sm border-l-4 border-blue-500">
                 <div className="flex items-center gap-3 mb-2 text-blue-600">
                   <UserPlus />
                   <h3 className="font-bold">Total Clientes</h3>
                 </div>
                 <p className="text-3xl font-bold">{users.filter(u => u.role === 'CLIENT').length}</p>
               </div>
               <div className="bg-white p-6 rounded-xl shadow-sm border-l-4 border-green-500">
                 <div className="flex items-center gap-3 mb-2 text-green-600">
                   <TrendingUp />
                   <h3 className="font-bold">Vendas (Pts)</h3>
                 </div>
                 <p className="text-3xl font-bold">
                    {users.reduce((acc, curr) => acc + (Number(curr.points) || 0), 0)} pts
                 </p>
               </div>
               <div className="bg-white p-6 rounded-xl shadow-sm border-l-4 border-purple-500">
                 <div className="flex items-center gap-3 mb-2 text-purple-600">
                   <Award />
                   <h3 className="font-bold">Resgates</h3>
                 </div>
                 <p className="text-3xl font-bold">
                    {Math.floor(users.reduce((acc, curr) => acc + (Number(curr.points) || 0), 0) / 500)}
                 </p>
               </div>
             </div>

             {/* User List */}
             <div className="bg-white rounded-xl shadow-sm overflow-hidden">
               <div className="p-4 border-b flex justify-between items-center">
                 <div className="flex items-center gap-4">
                   <h2 className="font-bold text-lg">Gerenciar Usuários</h2>
                   <button 
                    onClick={handleCreateUser}
                    className="bg-blue-600 text-white px-3 py-1.5 rounded-lg text-sm font-bold flex items-center gap-1 hover:bg-blue-700 transition"
                   >
                     <UserPlus size={16} /> Novo Usuário
                   </button>
                 </div>
                 <div className="relative">
                   <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={18} />
                   <input 
                    className="pl-10 pr-4 py-2 border rounded-lg text-sm w-64" 
                    placeholder="Buscar por nome ou CPF..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                   />
                 </div>
               </div>
               <div className="overflow-x-auto">
                 <table className="w-full text-sm text-left">
                   <thead className="bg-gray-50 text-gray-600 font-semibold">
                     <tr>
                       <th className="p-4">Usuário</th>
                       <th className="p-4">Plano / Função</th>
                       <th className="p-4">Solicitações</th>
                       <th className="p-4">Pontos</th>
                       <th className="p-4 text-center">Ações</th>
                     </tr>
                   </thead>
                   <tbody className="divide-y">
                     {filteredUsers.map(user => (
                       <tr key={user.id} className="hover:bg-gray-50">
                         <td className="p-4 whitespace-nowrap">
                           <div className="font-bold text-gray-800 flex items-center gap-1">
                             {user.fullName}
                             {user.role === 'ADMIN' && <ShieldAlert size={14} className="text-purple-500" title="Administrador" />}
                           </div>
                           <div className="text-xs text-gray-500 whitespace-nowrap">{user.phone}</div>
                         </td>
                         <td className="p-4">
                            {user.role === 'ADMIN' ? (
                              <span className="px-2 py-1 rounded text-xs font-bold bg-purple-100 text-purple-800 border border-purple-200">
                                ADMIN
                              </span>
                            ) : (
                              <span className={`px-2 py-1 rounded text-xs font-bold ${
                                user.tier === 'GOLD' ? 'bg-yellow-100 text-yellow-800' :
                                user.tier === 'SILVER' ? 'bg-gray-100 text-gray-800' :
                                user.tier === 'BRONZE' ? 'bg-orange-100 text-orange-800' : 'text-gray-500'
                              }`}>
                                {user.tier}
                              </span>
                            )}
                         </td>
                         <td className="p-4">
                           {user.pendingTier && (
                             <div className="flex items-center gap-2 animate-pulse mb-1">
                               <AlertTriangle size={14} className="text-yellow-500" />
                               <span className="text-xs font-bold text-yellow-700 bg-yellow-100 px-2 py-1 rounded whitespace-nowrap">
                                 Quer: {TIERS[user.pendingTier].name}
                               </span>
                             </div>
                           )}
                           
                           {/* Pending Purchase Indicator */}
                           {user.pendingPurchase && (
                             <div className="flex items-center gap-2 animate-pulse mb-1">
                               <ShoppingBag size={14} className="text-green-500" />
                               <span className="text-xs font-bold text-green-700 bg-green-100 px-2 py-1 rounded whitespace-nowrap">
                                 Comprou?
                               </span>
                             </div>
                           )}

                           {/* Pending Referral Indicator */}
                           {user.pendingReferrals && user.pendingReferrals.length > 0 && (
                             <button
                               onClick={() => setManagingReferralsUser(user)}
                               className="flex items-center gap-2 animate-pulse hover:bg-purple-100 transition rounded"
                             >
                               <Users size={14} className="text-purple-500" />
                               <span className="text-xs font-bold text-purple-700 bg-purple-100 px-2 py-1 rounded whitespace-nowrap border border-purple-200">
                                 🗣️ {user.pendingReferrals.length} Indicação(ões)
                               </span>
                             </button>
                           )}
                         </td>
                         <td className="p-4 font-mono font-bold text-blue-600">
                           {Number(user.points)}
                         </td>
                         <td className="p-4">
                           <div className="flex items-center gap-2 justify-end">
                             
                             {/* Purchase Approval Button */}
                             {user.pendingPurchase && (
                               <button 
                                onClick={() => handleApprovePurchase(user)}
                                className="bg-green-600 text-white hover:bg-green-700 px-3 py-2 rounded-md text-xs font-bold transition-colors flex items-center gap-1 shadow-md whitespace-nowrap"
                                title="Confirmar Compra e Adicionar 10 Pontos"
                               >
                                 <Check size={14} /> Aprovar Compra (+10)
                               </button>
                             )}

                             {/* Subscription Approval Button */}
                             {user.pendingTier && (
                               <button 
                                onClick={() => handleApproveTier(user)}
                                className="bg-blue-600 text-white hover:bg-blue-700 px-3 py-2 rounded-md text-xs font-bold transition-colors flex items-center gap-1 shadow-md whitespace-nowrap"
                               >
                                 <Check size={14} /> Aprovar {TIERS[user.pendingTier].name.split(' ')[1] || 'Troca'}
                               </button>
                             )}
                             
                             {!user.pendingPurchase && (
                               <>
                                 <button 
                                  onClick={(e) => handleAdjustPoints(e, user, 10)}
                                  className="bg-green-100 text-green-700 hover:bg-green-200 border border-green-200 px-2 py-2 rounded-md transition-colors flex items-center gap-1"
                                  title="Adicionar 10 Pontos"
                                 >
                                   <Check size={14} /> +10
                                 </button>
                                 
                                 <button 
                                  onClick={(e) => handleAdjustPoints(e, user, -10)}
                                  className="bg-red-100 text-red-700 hover:bg-red-200 border border-red-200 px-2 py-2 rounded-md transition-colors flex items-center gap-1"
                                  title="Remover 10 Pontos"
                                 >
                                   <Minus size={14} /> -10
                                 </button>
                               </>
                             )}

                             <button 
                               onClick={() => setImpersonatingUser(user)}
                               className="bg-yellow-100 text-yellow-600 hover:bg-yellow-200 border border-yellow-200 p-2 rounded-md transition-colors"
                               title="Simular Ambiente do Cliente"
                             >
                               <MonitorPlay size={14} />
                             </button>

                             <button 
                              onClick={() => { setEditingClient(user); setIsCreating(false); }}
                              className="bg-gray-100 text-gray-600 hover:bg-gray-200 border border-gray-200 p-2 rounded-md transition-colors"
                              title="Editar Dados do Usuário"
                             >
                               <Pencil size={14} />
                             </button>

                             {user.username !== 'admin' && (
                               <button 
                                onClick={() => handleDeleteUser(user.id)}
                                className="bg-red-50 text-red-500 hover:bg-red-100 border border-red-100 p-2 rounded-md transition-colors"
                                title="Excluir Usuário"
                               >
                                 <Trash2 size={14} />
                               </button>
                             )}
                           </div>
                         </td>
                       </tr>
                     ))}
                     {filteredUsers.length === 0 && (
                       <tr>
                         <td colSpan={5} className="p-8 text-center text-gray-500">Nenhum usuário encontrado.</td>
                       </tr>
                     )}
                   </tbody>
                 </table>
               </div>
             </div>
          </div>

          {/* Sidebar Analysis */}
          <div className="space-y-6">
            <div className="bg-white p-6 rounded-xl shadow-sm">
               <h3 className="font-bold mb-4">Adesão por Nível</h3>
               <div className="h-64">
                 <ResponsiveContainer width="100%" height="100%">
                   <BarChart data={tierData}>
                     <CartesianGrid strokeDasharray="3 3" vertical={false} />
                     <XAxis dataKey="name" axisLine={false} tickLine={false} />
                     <YAxis axisLine={false} tickLine={false} />
                     <Tooltip />
                     <Bar dataKey="count" fill="#3b82f6" radius={[4, 4, 0, 0]} />
                   </BarChart>
                 </ResponsiveContainer>
               </div>
            </div>

            <div className="bg-gradient-to-br from-indigo-900 to-blue-900 p-6 rounded-xl shadow-md text-white">
              <div className="flex items-center gap-2 mb-4">
                <Sparkles className="text-yellow-400" />
                <h3 className="font-bold text-lg">Smart Insights</h3>
              </div>
              
              {!insight ? (
                <div className="text-center py-6">
                  <p className="text-blue-200 text-sm mb-4">Use nossa IA para analisar a performance do programa de fidelidade.</p>
                  <button 
                    onClick={handleGenerateInsight}
                    disabled={loadingInsight}
                    className="w-full bg-white text-blue-900 font-bold py-2 rounded shadow hover:bg-blue-50 transition-colors flex justify-center items-center gap-2"
                  >
                    {loadingInsight ? <Loader2 className="animate-spin" size={16} /> : 'Gerar Relatório'}
                  </button>
                </div>
              ) : (
                <div className="animate-fade-in">
                  <div className="prose prose-invert prose-sm max-h-60 overflow-y-auto custom-scrollbar">
                     {/* Basic markdown rendering substitute */}
                     {insight.split('\n').map((line, i) => (
                       <p key={i} className="text-sm text-blue-100 mb-1">{line.replace(/[#*]/g, '')}</p>
                     ))}
                  </div>
                  <button 
                    onClick={() => setInsight(null)}
                    className="mt-4 text-xs text-blue-300 underline w-full text-center hover:text-white"
                  >
                    Gerar Novo
                  </button>
                </div>
              )}
            </div>

            {/* Backup & Security Card */}
            <div className="bg-slate-800 p-6 rounded-xl shadow-md text-white border border-slate-700">
               <div className="flex items-center gap-2 mb-4">
                  <Database className="text-green-400" size={20} />
                  <h3 className="font-bold text-lg">Segurança & Backup</h3>
               </div>
               <p className="text-slate-400 text-xs mb-4">
                 Os dados são salvos automaticamente no seu navegador. Para garantir que você nunca perca os cadastros, faça downloads regulares do backup.
               </p>
               
               <div className="space-y-3">
                 <button 
                   onClick={handleExportBackup}
                   className="w-full bg-slate-700 hover:bg-slate-600 border border-slate-600 text-white font-bold py-2 px-4 rounded transition flex items-center justify-center gap-2"
                 >
                   <Download size={16} /> Baixar Backup
                 </button>
                 
                 <div className="relative">
                   <input 
                     type="file" 
                     accept=".json" 
                     onChange={handleImportBackup}
                     className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                   />
                   <button className="w-full bg-slate-700 hover:bg-slate-600 border border-slate-600 text-white font-bold py-2 px-4 rounded transition flex items-center justify-center gap-2">
                     <Upload size={16} /> Restaurar Backup
                   </button>
                 </div>
               </div>
            </div>
          </div>
        </div>
        
        {/* Render Modal if Editing or Creating */}
        <EditClientModal />
        
        {/* Render Modal if Managing Referrals */}
        <ManageReferralsModal />
    </div>
  );

  const ProfileView = () => {
    const [formData, setFormData] = useState({
      username: currentUser.username,
      password: currentUser.password || '',
      fullName: currentUser.fullName,
      email: currentUser.email,
      phone: currentUser.phone,
      street: currentUser.address.street,
      number: currentUser.address.number,
      complement: currentUser.address.complement || '',
      district: currentUser.address.district,
      city: currentUser.address.city,
      uf: currentUser.address.uf,
      cep: currentUser.address.cep
    });
    const [loading, setLoading] = useState(false);
    const [loadingCep, setLoadingCep] = useState(false);
    const [showPassword, setShowPassword] = useState(false);

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
      // @ts-ignore
      setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    const handleCepChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
      const rawCep = e.target.value;
      setFormData(prev => ({ ...prev, cep: rawCep }));
      const cleanCep = rawCep.replace(/\D/g, '');

      if (cleanCep.length === 8) {
        setLoadingCep(true);
        try {
          const response = await fetch(`https://viacep.com.br/ws/${cleanCep}/json/`);
          const data = await response.json();
          if (!data.erro) {
            setFormData(prev => ({
              ...prev,
              street: data.logradouro,
              district: data.bairro,
              city: data.localidade,
              uf: data.uf,
            }));
          }
        } catch (error) {
          console.error("Erro CEP", error);
        } finally {
          setLoadingCep(false);
        }
      }
    };

    const handleSave = async (e: React.FormEvent) => {
      e.preventDefault();
      setLoading(true);

      if (formData.username !== currentUser.username && checkUsernameExists(formData.username, currentUser.id)) {
        alert("Nome de usuário já existe. Escolha outro.");
        setLoading(false);
        return;
      }

      await new Promise(r => setTimeout(r, 800)); // Simulate network

      const updatedUser: User = {
        ...currentUser,
        username: formData.username,
        fullName: formData.fullName,
        email: formData.email,
        phone: formData.phone,
        password: formData.password,
        address: {
          street: formData.street,
          number: formData.number,
          complement: formData.complement,
          district: formData.district,
          city: formData.city,
          uf: formData.uf,
          cep: formData.cep
        }
      };

      onUserUpdate(updatedUser);
      setLoading(false);
      alert("Dados atualizados com sucesso!");
    };

    return (
      <div className="max-w-4xl animate-fade-in">
        <h2 className="text-2xl font-bold text-gray-800 mb-6 flex items-center gap-2">
          <UserIcon className="text-blue-600" /> Meus Dados
        </h2>
        
        <form onSubmit={handleSave} className="bg-white p-6 md:p-8 rounded-2xl shadow-sm border border-gray-100 grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="col-span-1 md:col-span-2 bg-blue-50 p-4 rounded-xl mb-2">
             <h3 className="font-bold text-blue-800 mb-3">Informações de Acesso</h3>
             <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-bold text-blue-600 uppercase ml-1">Usuário</label>
                  <input required name="username" value={formData.username} onChange={handleChange} className="w-full p-2 bg-white border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 outline-none" />
                </div>
                <div className="relative">
                  <label className="text-xs font-bold text-blue-600 uppercase ml-1">Senha</label>
                  <input required type={showPassword ? "text" : "password"} name="password" value={formData.password} onChange={handleChange} className="w-full p-2 bg-white border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 outline-none pr-10" />
                  <button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute right-2 top-8 text-gray-400 hover:text-blue-600">
                     {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                  </button>
                </div>
             </div>
          </div>

          <div>
             <label className="text-xs font-bold text-gray-500 uppercase ml-1">Nome Completo</label>
             <input required name="fullName" value={formData.fullName} onChange={handleChange} className="w-full p-2 bg-white border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 outline-none" />
          </div>

          <div>
             <label className="text-xs font-bold text-gray-500 uppercase ml-1">CPF (Não alterável)</label>
             <input disabled value={currentUser.cpf} className="w-full p-2 bg-gray-200 border border-gray-300 rounded text-gray-500 cursor-not-allowed" />
          </div>

          <div>
             <label className="text-xs font-bold text-gray-500 uppercase ml-1">Email</label>
             <input required name="email" value={formData.email} onChange={handleChange} className="w-full p-2 bg-white border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 outline-none" />
          </div>

          <div>
             <label className="text-xs font-bold text-gray-500 uppercase ml-1">Telefone / WhatsApp</label>
             <input required name="phone" value={formData.phone} onChange={handleChange} className="w-full p-2 bg-white border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 outline-none" />
          </div>

          <div className="col-span-1 md:col-span-2 border-t pt-4 mt-2">
            <h3 className="font-bold text-gray-700 mb-4 flex items-center gap-2">
              <span className="bg-gray-100 p-1.5 rounded text-gray-600"><Home size={16}/></span> Endereço
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-6 gap-4">
               <div className="md:col-span-2 relative">
                 <label className="text-xs font-bold text-gray-500 uppercase ml-1">CEP</label>
                 <div className="relative">
                   <input required name="cep" value={formData.cep} onChange={handleCepChange} maxLength={9} className="w-full p-2 bg-white border border-gray-300 rounded pr-8 focus:ring-2 focus:ring-blue-500 outline-none" />
                   <div className="absolute right-2 top-1/2 -translate-y-1/2 text-gray-400">
                     {loadingCep ? <Loader2 className="animate-spin text-blue-500" size={14} /> : <Search size={14} />}
                   </div>
                 </div>
               </div>
               <div className="md:col-span-3">
                 <label className="text-xs font-bold text-gray-500 uppercase ml-1">Rua</label>
                 <input required name="street" value={formData.street} onChange={handleChange} className="w-full p-2 bg-white border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 outline-none" />
               </div>
               <div className="md:col-span-1">
                 <label className="text-xs font-bold text-gray-500 uppercase ml-1">Número</label>
                 <input required name="number" value={formData.number} onChange={handleChange} className="w-full p-2 bg-white border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 outline-none" />
               </div>
               <div className="md:col-span-2">
                 <label className="text-xs font-bold text-gray-500 uppercase ml-1">Complemento</label>
                 <input name="complement" value={formData.complement} onChange={handleChange} className="w-full p-2 bg-white border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 outline-none" />
               </div>
               <div className="md:col-span-2">
                 <label className="text-xs font-bold text-gray-500 uppercase ml-1">Bairro</label>
                 <input required name="district" value={formData.district} onChange={handleChange} className="w-full p-2 bg-white border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 outline-none" />
               </div>
               <div className="md:col-span-1">
                 <label className="text-xs font-bold text-gray-500 uppercase ml-1">Cidade</label>
                 <input required name="city" value={formData.city} onChange={handleChange} className="w-full p-2 bg-white border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 outline-none" />
               </div>
               <div className="md:col-span-2">
                 <label className="text-xs font-bold text-gray-500 uppercase ml-1">UF</label>
                 <select name="uf" value={formData.uf} onChange={handleChange} className="w-full p-2 border rounded">
                   <option value="">UF</option>
                   {BR_STATES.map(s => <option key={s} value={s}>{s}</option>)}
                 </select>
               </div>
            </div>
          </div>

          <div className="col-span-1 md:col-span-2 pt-4 flex justify-end">
             <button disabled={loading} className="bg-green-600 text-white px-8 py-3 rounded-xl font-bold hover:bg-green-700 shadow-lg shadow-green-200 transition flex items-center gap-2">
               {loading ? <Loader2 className="animate-spin" /> : <><Save size={20} /> SALVAR ALTERAÇÕES</>}
             </button>
          </div>
        </form>
      </div>
    );
  };

  const NavItem = ({ view, label, icon: Icon }: { view: ViewState, label: string, icon: any }) => (
    <button
      onClick={() => {
        setCurrentView(view);
        setMobileMenuOpen(false);
      }}
      className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl font-medium transition-all duration-200 ${
        currentView === view 
          ? 'bg-blue-600 text-white shadow-lg shadow-blue-600/30' 
          : 'text-slate-400 hover:bg-slate-800 hover:text-white'
      }`}
    >
      <Icon size={20} />
      <span>{label}</span>
    </button>
  );

  return (
    <div className="flex min-h-screen bg-slate-50 font-sans text-slate-800">
      
      {/* Sidebar (Desktop) */}
      <aside className={`fixed inset-y-0 left-0 z-50 w-64 bg-slate-900 text-white transform transition-transform duration-300 ease-in-out ${mobileMenuOpen ? 'translate-x-0' : '-translate-x-full'} md:translate-x-0 md:static md:flex-shrink-0`}>
        <div className="h-full flex flex-col p-6">
          <div className="mb-10 flex items-center justify-center">
            {/* Custom logo wrapper for dark bg */}
            <div className="bg-white/10 p-2 rounded-xl backdrop-blur-sm">
               <Logo size="md" /> 
            </div>
          </div>

          <div className="mb-4 px-2 text-xs font-bold text-slate-500 uppercase tracking-widest">
            Administrativo
          </div>

          <nav className="flex-1 space-y-2">
            <NavItem view="DASHBOARD" label="Visão Geral" icon={Home} />
            <NavItem view="PROFILE" label="Meus Dados" icon={UserIcon} />
          </nav>

          <div className="pt-6 border-t border-slate-800">
             <div className="flex items-center gap-3 px-2 mb-4">
               <div className="w-10 h-10 rounded-full bg-purple-500 flex items-center justify-center text-white font-bold">
                 AD
               </div>
               <div className="overflow-hidden">
                 <p className="text-sm font-bold truncate text-white">{currentUser.fullName}</p>
                 <p className="text-xs text-slate-400 truncate">Gerente</p>
               </div>
             </div>
             <button 
               onClick={onLogout}
               className="w-full flex items-center gap-3 px-4 py-2 text-slate-400 hover:text-red-400 transition-colors"
             >
               <LogOut size={20} />
               <span>Sair da conta</span>
             </button>
          </div>
        </div>
      </aside>

      {/* Overlay for mobile sidebar */}
      {mobileMenuOpen && (
        <div 
          className="fixed inset-0 bg-black/50 z-40 md:hidden backdrop-blur-sm"
          onClick={() => setMobileMenuOpen(false)}
        />
      )}

      {/* Main Content Area */}
      <main className="flex-1 flex flex-col h-screen overflow-hidden">
        {/* Mobile Header */}
        <header className="md:hidden bg-white border-b border-gray-200 p-4 flex items-center justify-between z-30 sticky top-0">
          <button onClick={() => setMobileMenuOpen(true)} className="text-slate-600">
            <Menu size={24} />
          </button>
          <div className="scale-75 origin-center">
            <Logo size="sm" />
          </div>
          <div className="w-6" /> 
        </header>

        {/* Scrollable Content */}
        <div className="flex-1 overflow-y-auto p-4 md:p-8 lg:p-12">
          <div className="max-w-7xl mx-auto">
             <div className="flex justify-between items-center mb-8">
               <h1 className="text-2xl font-bold text-gray-800">
                 {currentView === 'DASHBOARD' ? 'Painel de Controle' : 'Minhas Informações'}
               </h1>
             </div>
             
             {currentView === 'DASHBOARD' && <DashboardView />}
             {currentView === 'PROFILE' && <ProfileView />}
          </div>
        </div>
      </main>
    </div>
  );
};

export default AdminDashboard;