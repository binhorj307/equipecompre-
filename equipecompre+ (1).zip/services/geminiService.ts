import { GoogleGenAI } from "@google/genai";
import { User, SubscriptionTier } from "../types";

export const generateAdminInsights = async (users: User[]) => {
  try {
    if (!process.env.API_KEY) {
      return "Chave de API não configurada. Não é possível gerar insights.";
    }

    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    
    const clientCount = users.filter(u => u.role === 'CLIENT').length;
    const tierCounts = users.reduce((acc, user) => {
        acc[user.tier] = (acc[user.tier] || 0) + 1;
        return acc;
    }, {} as Record<string, number>);

    const prompt = `
      Atue como um especialista em marketing de fidelidade. Analise os dados resumidos abaixo da loja 'EquipeCompreMais' e forneça 3 insights estratégicos curtos e uma ação recomendada para aumentar a adesão aos planos Bronze, Prata e Ouro.
      
      Dados:
      - Total de Clientes: ${clientCount}
      - Distribuição de Níveis: ${JSON.stringify(tierCounts)}
      
      Responda em formato de lista Markdown. Seja motivador e foque em vendas.
    `;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
    });

    return response.text;
  } catch (error) {
    console.error("Error generating insights:", error);
    return "Não foi possível gerar insights no momento. Verifique a conexão.";
  }
};