import { User, UserRole, SubscriptionTier } from '../types';

const USERS_KEY = 'equipe_users';
const CURRENT_USER_KEY = 'equipe_current_user';

// Ensure an admin always exists
const initUsers = () => {
  let users: User[] = [];
  try {
    const stored = localStorage.getItem(USERS_KEY);
    users = stored ? JSON.parse(stored) : [];
  } catch (e) {
    users = [];
  }
  
  // Check specifically for the default 'admin' username to guarantee access
  const defaultAdminExists = users.some(u => u.username === 'admin');

  if (!defaultAdminExists) {
    const admin: User = {
      id: 'admin-default-' + Date.now(),
      username: 'admin',
      password: 'Xy453200*', // Updated to requested strong password
      role: UserRole.ADMIN,
      points: 0,
      tier: SubscriptionTier.GOLD,
      cpf: '000.000.000-00',
      fullName: 'Administrador Equipe',
      email: 'admin@equipe.com',
      phone: '21985415117',
      address: {
        street: 'Loja', number: '1', district: 'Centro', city: 'Rio de Janeiro', uf: 'RJ', cep: '20000-000'
      },
      history: [],
      joinDate: new Date().toISOString()
    };
    users.push(admin);
    localStorage.setItem(USERS_KEY, JSON.stringify(users));
  }
};

export const getUsers = (): User[] => {
  initUsers();
  const users = JSON.parse(localStorage.getItem(USERS_KEY) || '[]');
  // Force points to be numbers to avoid string concatenation issues
  return users.map((u: User) => ({
    ...u,
    points: Number(u.points) || 0
  }));
};

// Helper to get the first admin (for login hint)
export const getFirstAdmin = (): User | undefined => {
  const users = getUsers();
  // Prefer the one named 'admin', otherwise any admin
  return users.find(u => u.username === 'admin') || users.find(u => u.role === UserRole.ADMIN);
};

export const saveUser = (user: User) => {
  const users = getUsers();
  // Ensure history is initialized and points are number
  if (!user.history) user.history = [];
  user.points = Number(user.points) || 0;
  
  users.push(user);
  localStorage.setItem(USERS_KEY, JSON.stringify(users));
  return user;
};

export const updateUser = (updatedUser: User) => {
  const users = getUsers();
  const index = users.findIndex(u => u.id === updatedUser.id);
  if (index !== -1) {
    // Ensure points are number before saving
    updatedUser.points = Number(updatedUser.points) || 0;
    
    users[index] = updatedUser;
    localStorage.setItem(USERS_KEY, JSON.stringify(users));
    
    // Update session if it's the current user
    const current = getCurrentUser();
    if (current && current.id === updatedUser.id) {
      localStorage.setItem(CURRENT_USER_KEY, JSON.stringify(updatedUser));
    }
  }
};

export const deleteUser = (userId: string) => {
  let users = getUsers();
  users = users.filter(u => u.id !== userId);
  localStorage.setItem(USERS_KEY, JSON.stringify(users));
};

// New function to import data safely
export const importUsersData = (jsonString: string): boolean => {
  try {
    const parsed = JSON.parse(jsonString);
    if (Array.isArray(parsed) && parsed.length > 0) {
      // Basic validation: check if items look like users (have id and username)
      const valid = parsed.every(u => u.id && u.username);
      if (valid) {
        localStorage.setItem(USERS_KEY, JSON.stringify(parsed));
        return true;
      }
    }
  } catch (e) {
    console.error("Invalid JSON for import", e);
  }
  return false;
};

export const login = (username: string, password: string): User | null => {
  const users = getUsers();
  const normalizedUsername = username.trim().toLowerCase();
  
  const user = users.find(u => 
    u.username.toLowerCase() === normalizedUsername && 
    u.password === password
  );
  
  if (user) {
    // Ensure history exists on login for older records
    if (!user.history) user.history = [];
    user.points = Number(user.points) || 0;
    localStorage.setItem(CURRENT_USER_KEY, JSON.stringify(user));
    return user;
  }
  return null;
};

export const logout = () => {
  localStorage.removeItem(CURRENT_USER_KEY);
};

export const getCurrentUser = (): User | null => {
  const stored = localStorage.getItem(CURRENT_USER_KEY);
  const user = stored ? JSON.parse(stored) : null;
  if (user) {
    if (!user.history) user.history = [];
    user.points = Number(user.points) || 0;
  }
  return user;
};

// Updated to allow excluding a user ID (for updates)
export const checkUsernameExists = (username: string, excludeUserId?: string): boolean => {
  const users = getUsers();
  return users.some(u => u.username.toLowerCase() === username.trim().toLowerCase() && u.id !== excludeUserId);
};

export const findUserByIdentifier = (identifier: string): User | undefined => {
  const users = getUsers();
  const normalizedIdentifier = identifier.trim().toLowerCase();
  // Check against username or email
  return users.find(u => 
    u.username.toLowerCase() === normalizedIdentifier || 
    u.email.toLowerCase() === normalizedIdentifier
  );
};